import {
  Check,
  CheckCircle2,
  ChevronDown,
  Clock,
  Stethoscope,
  XCircle,
} from 'lucide-react';
import { EstadoTurno } from '../types/veterinaria';
import { ESTADOS_TURNO } from '../utils/formatters';

interface StatusBadgeProps {
  estado: EstadoTurno;
}

export function StatusText({ estado }: StatusBadgeProps) {
  switch (estado) {
    case 'Pendiente':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 whitespace-nowrap">
          <Clock size={14} strokeWidth={2} aria-hidden="true" />
          <span>Pendiente</span>
        </span>
      );
    case 'Confirmado':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-sky-700 whitespace-nowrap">
          <CheckCircle2 size={14} strokeWidth={2} aria-hidden="true" />
          <span>Confirmado</span>
        </span>
      );
    case 'En consulta':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal-700 whitespace-nowrap">
          <Stethoscope size={14} strokeWidth={2} aria-hidden="true" />
          <span>En consulta</span>
        </span>
      );
    case 'Completado':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 whitespace-nowrap">
          <Check size={14} strokeWidth={2.2} aria-hidden="true" />
          <span>Completado</span>
        </span>
      );
    case 'Cancelado':
      return (
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 whitespace-nowrap">
          <XCircle size={14} strokeWidth={2} aria-hidden="true" />
          <span>Cancelado</span>
        </span>
      );
  }
}

interface StatusSelectorProps {
  estado: EstadoTurno;
  onChange: (nuevoEstado: EstadoTurno) => void;
  ariaLabel?: string;
}

function getSelectorTone(estado: EstadoTurno): string {
  switch (estado) {
    case 'Pendiente':
      return 'border-amber-300 bg-amber-50/70 text-amber-800 hover:border-amber-400';
    case 'Confirmado':
      return 'border-sky-300 bg-sky-50/70 text-sky-800 hover:border-sky-400';
    case 'En consulta':
      return 'border-teal-400 bg-teal-50 text-teal-900 hover:border-teal-500';
    case 'Completado':
      return 'border-emerald-300 bg-emerald-50/70 text-emerald-800 hover:border-emerald-400';
    case 'Cancelado':
      return 'border-slate-200 bg-slate-100 text-slate-600 hover:border-slate-300';
  }
}

function StatusIcon({ estado }: { estado: EstadoTurno }) {
  switch (estado) {
    case 'Pendiente':
      return <Clock size={14} strokeWidth={2} aria-hidden="true" />;
    case 'Confirmado':
      return <CheckCircle2 size={14} strokeWidth={2} aria-hidden="true" />;
    case 'En consulta':
      return <Stethoscope size={14} strokeWidth={2} aria-hidden="true" />;
    case 'Completado':
      return <Check size={14} strokeWidth={2.2} aria-hidden="true" />;
    case 'Cancelado':
      return <XCircle size={14} strokeWidth={2} aria-hidden="true" />;
  }
}

export function StatusSelector({
  estado,
  onChange,
  ariaLabel = 'Cambiar estado del turno',
}: StatusSelectorProps) {
  return (
    <div
      className="relative inline-flex items-center shrink-0"
      onClick={(e) => e.stopPropagation()}
    >
      <span className="pointer-events-none absolute left-2.5 flex items-center">
        <StatusIcon estado={estado} />
      </span>
      <select
        aria-label={ariaLabel}
        value={estado}
        onChange={(e) => onChange(e.target.value as EstadoTurno)}
        className={`appearance-none cursor-pointer pl-7 pr-7 py-1.5 text-xs font-medium rounded-md border transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-600 whitespace-nowrap ${getSelectorTone(estado)}`}
      >
        {ESTADOS_TURNO.map((item) => (
          <option key={item} value={item} className="bg-white text-slate-900">
            {item}
          </option>
        ))}
      </select>
      <ChevronDown
        size={13}
        className="pointer-events-none absolute right-2 opacity-70"
        aria-hidden="true"
      />
    </div>
  );
}
