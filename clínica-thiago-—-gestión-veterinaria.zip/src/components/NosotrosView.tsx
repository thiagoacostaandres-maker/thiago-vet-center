import { useState } from 'react';
import { Building2, CalendarPlus } from 'lucide-react';
import { CLINIC_IMAGES } from '../data/seedData';

interface NosotrosViewProps {
  onBookAppointment: () => void;
}

const EQUIPO = [
  {
    nombre: 'Dra. Valeria Méndez',
    matricula: 'MP 8412',
    especialidad: 'Clínica médica y dermatología veterinaria',
    trayectoria: '11 años de experiencia en medicina interna de pequeños animales.',
  },
  {
    nombre: 'Dr. Martín Sosa',
    matricula: 'MP 9104',
    especialidad: 'Cirugía general y traumatología',
    trayectoria: 'Responsable del área quirúrgica y recuperación postoperatoria.',
  },
  {
    nombre: 'Dra. Lucía Ferreyra',
    matricula: 'MP 9855',
    especialidad: 'Medicina felina, odontología y prevención',
    trayectoria: 'Especializada en manejo amigable de gatos y control geriátrico.',
  },
];

export function NosotrosView({ onBookAppointment }: NosotrosViewProps) {
  const [imgFailed, setImgFailed] = useState(false);

  return (
    <div className="space-y-12">
      {/* Cabecera */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        <div className="lg:col-span-6 space-y-5 flex flex-col justify-center">
          <div className="space-y-3">
            <p className="text-xs font-medium text-teal-700">Sobre nosotros</p>
            <h1 className="text-3xl font-bold tracking-tight text-slate-900 [text-wrap:balance]">
              Clínica Thiago: medicina veterinaria con criterio preventivo y trato sereno
            </h1>
            <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
              Nacimos con la convicción de que una consulta veterinaria debe ser
              un espacio tranquilo tanto para la mascota como para su familia.
              Trabajamos con historia clínica digital unificada, salas
              separadas para perros y gatos, y seguimiento personalizado después
              de cada atención.
            </p>
            <p className="text-sm text-slate-600 leading-relaxed">
              Nuestras instalaciones cuentan con dos consultorios clínicos,
              quirófano de baja y mediana complejidad, área de diagnóstico por
              imágenes y sector exclusivo de peluquería higiénica.
            </p>
          </div>

          <div>
            <button
              type="button"
              onClick={onBookAppointment}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap"
            >
              <CalendarPlus size={16} />
              <span>Agendar una visita</span>
            </button>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="h-72 sm:h-88 lg:h-full min-h-[300px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
            {!imgFailed ? (
              <img
                src={CLINIC_IMAGES.about}
                alt="Consultorio y equipamiento diagnóstico de Clínica Thiago"
                referrerPolicy="no-referrer"
                onError={() => setImgFailed(true)}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center p-8 text-slate-500">
                <Building2 size={32} className="mb-2 text-teal-700" />
                <span className="text-sm">Instalaciones de Clínica Thiago</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Pilares de atención */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4 border-t border-slate-200">
        <div className="space-y-1.5">
          <h2 className="text-sm font-semibold text-slate-900">
            01. Atención sin apuros
          </h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            Turnos programados cada 30 minutos para escuchar a cada tutor y
            evaluar al paciente sin estrés en sala de espera.
          </p>
        </div>
        <div className="space-y-1.5">
          <h2 className="text-sm font-semibold text-slate-900">
            02. Historia clínica continua
          </h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            Cada vacuna, peso, alergia e indicación médica queda registrada y
            disponible en la ficha de tu mascota.
          </p>
        </div>
        <div className="space-y-1.5">
          <h2 className="text-sm font-semibold text-slate-900">
            03. Espacios diferenciados
          </h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            Consultorio adaptado para felinos y sector acústicamente aislado para
            baño y peluquería terapéutica.
          </p>
        </div>
      </section>

      {/* Equipo profesional */}
      <section className="space-y-5">
        <div className="border-b border-slate-200 pb-3">
          <h2 className="text-xl font-semibold text-slate-900">
            Equipo veterinario
          </h2>
          <p className="text-sm text-slate-500 mt-0.5">
            Profesionales matriculados dedicados a la clínica de pequeños animales.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {EQUIPO.map((doc) => (
            <article
              key={doc.matricula}
              className="bg-white border border-slate-200 rounded-xl p-5 space-y-2"
            >
              <div className="flex items-baseline justify-between gap-2">
                <h3 className="text-base font-semibold text-slate-900">
                  {doc.nombre}
                </h3>
                <span className="text-xs font-mono tabular-nums text-slate-500">
                  {doc.matricula}
                </span>
              </div>
              <p className="text-xs font-medium text-teal-700">
                {doc.especialidad}
              </p>
              <p className="text-sm text-slate-600 leading-relaxed pt-1">
                {doc.trayectoria}
              </p>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}
