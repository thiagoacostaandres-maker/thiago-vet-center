import { useMemo, useState } from 'react';
import { CalendarPlus, Plus, Search } from 'lucide-react';
import {
  Especie,
  Mascota,
  Propietario,
  Turno,
  Usuario,
} from '../types/veterinaria';
import { CLINIC_IMAGES } from '../data/seedData';
import { formatFechaCorta } from '../utils/formatters';
import { PetAvatar } from './PetAvatar';
import { StatusText } from './StatusControl';

interface MascotasViewProps {
  currentUser: Usuario | null;
  mascotas: Mascota[];
  propietarios: Propietario[];
  turnos: Turno[];
  onSelectPet: (mascotaId: string) => void;
  onBookForPet: (mascotaId: string) => void;
  onOpenNewPetModal: () => void;
  onOpenAccess: (mode: 'clienta' | 'admin') => void;
}

type EspecieFilter = 'Todas' | Especie;

export function MascotasView({
  currentUser,
  mascotas,
  propietarios,
  turnos,
  onSelectPet,
  onBookForPet,
  onOpenNewPetModal,
  onOpenAccess,
}: MascotasViewProps) {
  const [especieFilter, setEspecieFilter] = useState<EspecieFilter>('Todas');
  const [search, setSearch] = useState('');

  const ownerMap = useMemo(
    () => new Map(propietarios.map((p) => [p.id, p])),
    [propietarios]
  );

  const latestTurnoByPet = useMemo(() => {
    const map = new Map<string, Turno>();
    const sorted = [...turnos].sort((a, b) =>
      `${b.fecha} ${b.hora}`.localeCompare(`${a.fecha} ${a.hora}`)
    );
    for (const t of sorted) {
      if (!map.has(t.mascotaId)) {
        map.set(t.mascotaId, t);
      }
    }
    return map;
  }, [turnos]);

  const isAdmin = currentUser?.rol === 'Administrador';
  const isClienta = currentUser?.rol === 'Clienta';

  const scopedMascotas = useMemo(() => {
    if (isAdmin) return mascotas;
    if (isClienta && currentUser?.propietarioId) {
      return mascotas.filter(
        (m) => m.propietarioId === currentUser.propietarioId
      );
    }
    return [];
  }, [mascotas, isAdmin, isClienta, currentUser]);

  const filteredMascotas = useMemo(() => {
    const q = search.trim().toLowerCase();
    return scopedMascotas.filter((m) => {
      if (especieFilter !== 'Todas' && m.especie !== especieFilter) {
        return false;
      }
      if (!q) return true;
      const owner = ownerMap.get(m.propietarioId);
      return (
        m.nombre.toLowerCase().includes(q) ||
        m.raza.toLowerCase().includes(q) ||
        m.especie.toLowerCase().includes(q) ||
        (owner?.nombre.toLowerCase().includes(q) ?? false)
      );
    });
  }, [scopedMascotas, especieFilter, search, ownerMap]);

  return (
    <div className="space-y-10">
      {/* Sección informativa de Perros y Gatos */}
      <section className="space-y-5">
        <div className="max-w-2xl space-y-1.5">
          <p className="text-xs font-medium text-teal-700">
            Guía de cuidados por especie
          </p>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">
            Información de perros y gatos
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Pautas básicas de prevención, vacunación y control clínico para
            mantener saludables a tus compañeros en cada etapa.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <article className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row gap-5">
            <PetAvatar
              nombre="Perros"
              especie="Perro"
              fotoUrl={CLINIC_IMAGES.dogPortrait}
              size="lg"
            />
            <div className="space-y-2.5">
              <h2 className="text-lg font-semibold text-slate-900">Perros</h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Requieren refuerzo anual de vacuna séxtuple y antirrábica,
                desparasitación interna cada 3 meses y cepillado dental regular.
              </p>
              <ul className="text-xs text-slate-600 space-y-1">
                <li>· Control clínico semestral a partir de los 7 años</li>
                <li>· Prevención mensual contra pulgas, garrapatas y mosquitos</li>
                <li>· Dieta ajustada a tamaño, raza y actividad física</li>
              </ul>
            </div>
          </article>

          <article className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row gap-5">
            <PetAvatar
              nombre="Gatos"
              especie="Gato"
              fotoUrl={CLINIC_IMAGES.catPortrait}
              size="lg"
            />
            <div className="space-y-2.5">
              <h2 className="text-lg font-semibold text-slate-900">Gatos</h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Recomendamos vacuna triple felina y antirrábica anual, control de
                peso e hidratación constante con bebederos separados del alimento.
              </p>
              <ul className="text-xs text-slate-600 space-y-1">
                <li>· Sala de espera y consultorio adaptados para reducir el estrés</li>
                <li>· Chequeo renal y urinario preventivo en gatos adultos</li>
                <li>· Enriquecimiento ambiental y control de bolas de pelo</li>
              </ul>
            </div>
          </article>
        </div>
      </section>

      <hr className="border-slate-200" />

      {/* Directorio clínico de mascotas registradas */}
      {!currentUser ? (
        <div className="bg-white border border-slate-200 rounded-xl p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <h2 className="text-lg font-semibold text-slate-900">
              Fichas clínicas y tus mascotas
            </h2>
            <p className="text-sm text-slate-600">
              Ingresá como clienta para ver y registrar tus mascotas, o como
              administrador para consultar todo el padrón clínico.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => onOpenAccess('clienta')}
              className="px-4 py-2 text-xs font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 whitespace-nowrap"
            >
              Ingresar como clienta
            </button>
            <button
              type="button"
              onClick={() => onOpenAccess('admin')}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 whitespace-nowrap"
            >
              Acceso administrador
            </button>
          </div>
        </div>
      ) : (
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-semibold tracking-tight text-slate-900">
              {isAdmin ? 'Pacientes registrados' : 'Mis mascotas'}
            </h2>
            <p className="text-sm text-slate-500 mt-1">
              {isAdmin
                ? 'Directorio de historias clínicas, datos biométricos y tutores vinculados.'
                : 'Tus mascotas registradas y acceso directo para reservar consultas.'}
            </p>
          </div>

          <button
            type="button"
            onClick={onOpenNewPetModal}
            className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-800 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
          >
            <Plus size={16} />
            <span>Registrar mascota</span>
          </button>
        </div>

      {/* Filtros y búsqueda */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg overflow-x-auto max-w-full">
          {(['Todas', 'Perro', 'Gato', 'Conejo', 'Ave', 'Otro'] as const).map(
            (esp) => (
              <button
                key={esp}
                type="button"
                onClick={() => setEspecieFilter(esp)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  especieFilter === esp
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {esp}
              </button>
            )
          )}
        </div>

        <div className="relative w-full md:w-72 shrink-0">
          <Search
            size={15}
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar mascota, raza o tutor..."
            aria-label="Buscar mascotas"
            className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-200 rounded-lg placeholder:text-slate-400 focus:outline-none focus:border-teal-600"
          />
        </div>
      </div>

      {filteredMascotas.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
          <p className="text-sm font-medium text-slate-900">
            No se encontraron mascotas con ese criterio.
          </p>
          <button
            type="button"
            onClick={onOpenNewPetModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800"
          >
            <Plus size={14} />
            <span>Registrar mascota</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredMascotas.map((pet) => {
            const owner = ownerMap.get(pet.propietarioId);
            const lastTurno = latestTurnoByPet.get(pet.id);

            return (
              <article
                key={pet.id}
                onClick={() => onSelectPet(pet.id)}
                className="bg-white border border-slate-200 rounded-xl p-5 hover:border-slate-300 transition-colors cursor-pointer flex flex-col justify-between gap-4"
              >
                <div className="flex items-start gap-3.5">
                  <PetAvatar
                    nombre={pet.nombre}
                    especie={pet.especie}
                    fotoUrl={pet.fotoUrl}
                    size="md"
                  />
                  <div className="min-w-0 flex-1">
                    <h2 className="text-base font-semibold text-slate-900 truncate">
                      {pet.nombre}
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5 truncate">
                      {pet.especie}
                      <span className="mx-1.5" aria-hidden="true">·</span>
                      {pet.raza}
                      <span className="mx-1.5" aria-hidden="true">·</span>
                      {pet.edad}
                    </p>
                    <p className="text-xs text-slate-500 mt-1 font-mono tabular-nums">
                      {pet.pesoKg} kg · {pet.sexo}
                    </p>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Propietario</span>
                    <span className="font-medium text-slate-800 truncate max-w-[180px]">
                      {owner?.nombre ?? 'Sin asignar'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Último turno</span>
                    {lastTurno ? (
                      <div className="flex items-center gap-2">
                        <span className="text-slate-600 font-mono tabular-nums">
                          {formatFechaCorta(lastTurno.fecha)}
                        </span>
                        <StatusText estado={lastTurno.estado} />
                      </div>
                    ) : (
                      <span className="text-slate-400">Sin turnos</span>
                    )}
                  </div>
                </div>

                <div
                  className="pt-2 flex items-center justify-between gap-2"
                  onClick={(e) => e.stopPropagation()}
                >
                  <button
                    type="button"
                    onClick={() => onSelectPet(pet.id)}
                    className="text-xs font-medium text-slate-600 hover:text-slate-900 whitespace-nowrap"
                  >
                    Ver ficha clínica
                  </button>
                  <button
                    type="button"
                    onClick={() => onBookForPet(pet.id)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-teal-800 bg-teal-50 border border-teal-200 rounded-md hover:bg-teal-100 transition-colors whitespace-nowrap shrink-0"
                  >
                    <CalendarPlus size={13} />
                    <span>Agendar consulta</span>
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      )}
      </div>
      )}
    </div>
  );
}
