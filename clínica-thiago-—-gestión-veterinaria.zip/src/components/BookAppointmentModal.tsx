import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import {
  Especie,
  EstadoTurno,
  Mascota,
  Propietario,
  SexoMascota,
  TipoConsulta,
  Turno,
  Usuario,
} from '../types/veterinaria';
import {
  getTodayISO,
  HORARIOS_DISPONIBLES,
  VETERINARIOS,
} from '../data/seedData';

interface BookAppointmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: Usuario | null;
  mascotas: Mascota[];
  propietarios: Propietario[];
  turnos: Turno[];
  preselectedMascotaId?: string;
  preselectedTipo?: TipoConsulta;
  onCreateAppointment: (payload: {
    turno: Omit<Turno, 'id' | 'codigo'>;
    newOwner?: Omit<Propietario, 'id'>;
    newPet?: Omit<Mascota, 'id' | 'propietarioId'>;
  }) => void;
}

const TIPOS_CONSULTA: TipoConsulta[] = [
  'Consulta general',
  'Vacunación',
  'Control clínico',
  'Cirugía',
  'Peluquería',
  'Desparasitación',
  'Urgencia',
];

const ESPECIES: Especie[] = ['Perro', 'Gato', 'Conejo', 'Ave', 'Otro'];

export function BookAppointmentModal({
  isOpen,
  onClose,
  currentUser,
  mascotas,
  propietarios,
  turnos,
  preselectedMascotaId,
  preselectedTipo,
  onCreateAppointment,
}: BookAppointmentModalProps) {
  const isClienta = currentUser?.rol === 'Clienta' && Boolean(currentUser.propietarioId);
  const visibleMascotas = isClienta
    ? mascotas.filter((m) => m.propietarioId === currentUser?.propietarioId)
    : mascotas;

  const [modoPaciente, setModoPaciente] = useState<'existente' | 'nuevo'>(
    'existente'
  );
  const [mascotaId, setMascotaId] = useState<string>('');

  // Campos de nuevo paciente + propietario
  const [ownerMode, setOwnerMode] = useState<'existente' | 'nuevo'>('nuevo');
  const [existingOwnerId, setExistingOwnerId] = useState<string>('');
  const [ownerNombre, setOwnerNombre] = useState('');
  const [ownerTelefono, setOwnerTelefono] = useState('');
  const [ownerEmail, setOwnerEmail] = useState('');
  const [ownerDireccion, setOwnerDireccion] = useState('');
  const [ownerDni, setOwnerDni] = useState('');

  const [petNombre, setPetNombre] = useState('');
  const [petEspecie, setPetEspecie] = useState<Especie>('Perro');
  const [petRaza, setPetRaza] = useState('');
  const [petEdad, setPetEdad] = useState('');
  const [petPeso, setPetPeso] = useState('');
  const [petSexo, setPetSexo] = useState<SexoMascota>('Macho');

  // Campos del turno
  const [fecha, setFecha] = useState(getTodayISO());
  const [hora, setHora] = useState('10:00');
  const [tipo, setTipo] = useState<TipoConsulta>('Consulta general');
  const [veterinario, setVeterinario] = useState(VETERINARIOS[0]);
  const [motivo, setMotivo] = useState('');
  const [observaciones, setObservaciones] = useState('');
  const [estadoInicial, setEstadoInicial] = useState<EstadoTurno>('Pendiente');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    setError('');
    setFecha(getTodayISO());
    setHora('10:00');
    setTipo(preselectedTipo || 'Consulta general');
    setVeterinario(VETERINARIOS[0]);
    setMotivo('');
    setObservaciones('');
    setEstadoInicial('Pendiente');

    const scopedPets =
      currentUser?.rol === 'Clienta' && currentUser.propietarioId
        ? mascotas.filter((m) => m.propietarioId === currentUser.propietarioId)
        : mascotas;

    if (preselectedMascotaId && scopedPets.some((m) => m.id === preselectedMascotaId)) {
      setModoPaciente('existente');
      setMascotaId(preselectedMascotaId);
    } else if (scopedPets.length > 0) {
      setModoPaciente('existente');
      setMascotaId(scopedPets[0].id);
    } else {
      setModoPaciente('nuevo');
    }

    if (currentUser?.rol === 'Clienta' && currentUser.propietarioId) {
      setOwnerMode('existente');
      setExistingOwnerId(currentUser.propietarioId);
    } else {
      if (propietarios.length > 0) {
        setExistingOwnerId(propietarios[0].id);
      }
      setOwnerMode(propietarios.length === 0 ? 'nuevo' : 'nuevo');
    }
    setOwnerNombre('');
    setOwnerTelefono('');
    setOwnerEmail('');
    setOwnerDireccion('');
    setOwnerDni('');
    setPetNombre('');
    setPetRaza('');
    setPetEdad('');
    setPetPeso('');
    setPetEspecie('Perro');
    setPetSexo('Macho');
  }, [isOpen, preselectedMascotaId, preselectedTipo, mascotas, propietarios, currentUser]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const ownerMap = new Map(propietarios.map((p) => [p.id, p]));

  const occupiedSlots = new Set(
    turnos
      .filter(
        (t) =>
          t.fecha === fecha &&
          t.veterinario === veterinario &&
          t.estado !== 'Cancelado'
      )
      .map((t) => t.hora)
  );

  const selectedPet = mascotas.find((m) => m.id === mascotaId);
  const selectedPetOwner = selectedPet
    ? ownerMap.get(selectedPet.propietarioId)
    : undefined;

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    if (!fecha || !hora) {
      setError('Seleccioná la fecha y el horario de la consulta.');
      return;
    }

    if (!motivo.trim()) {
      setError('Ingresá el motivo de la consulta.');
      return;
    }

    if (modoPaciente === 'existente') {
      const pet = mascotas.find((m) => m.id === mascotaId);
      if (!pet) {
        setError('Seleccioná una mascota válida.');
        return;
      }
      onCreateAppointment({
        turno: {
          mascotaId: pet.id,
          propietarioId: pet.propietarioId,
          fecha,
          hora,
          tipo,
          motivo: motivo.trim(),
          veterinario,
          estado: estadoInicial,
          observaciones: observaciones.trim() || undefined,
        },
      });
      onClose();
      return;
    }

    // Modo nuevo paciente
    if (!petNombre.trim()) {
      setError('Ingresá el nombre de la mascota.');
      return;
    }
    const pesoNum = parseFloat(petPeso.replace(',', '.')) || 0;

    if (ownerMode === 'existente') {
      if (!existingOwnerId) {
        setError('Seleccioná un propietario.');
        return;
      }
      onCreateAppointment({
        turno: {
          mascotaId: '',
          propietarioId: existingOwnerId,
          fecha,
          hora,
          tipo,
          motivo: motivo.trim(),
          veterinario,
          estado: estadoInicial,
          observaciones: observaciones.trim() || undefined,
        },
        newPet: {
          nombre: petNombre.trim(),
          especie: petEspecie,
          raza: petRaza.trim() || 'Mestizo',
          edad: petEdad.trim() || '1 año',
          pesoKg: pesoNum > 0 ? pesoNum : 5,
          sexo: petSexo,
          color: 'No especificado',
        },
      });
      onClose();
      return;
    }

    if (!ownerNombre.trim() || !ownerTelefono.trim()) {
      setError('Ingresá nombre y teléfono del propietario.');
      return;
    }

    onCreateAppointment({
      turno: {
        mascotaId: '',
        propietarioId: '',
        fecha,
        hora,
        tipo,
        motivo: motivo.trim(),
        veterinario,
        estado: estadoInicial,
        observaciones: observaciones.trim() || undefined,
      },
      newOwner: {
        nombre: ownerNombre.trim(),
        telefono: ownerTelefono.trim(),
        email: ownerEmail.trim() || 'sin-email@clinica.local',
        direccion: ownerDireccion.trim() || 'Sin domicilio registrado',
        dni: ownerDni.trim() || 'Sin DNI',
      },
      newPet: {
        nombre: petNombre.trim(),
        especie: petEspecie,
        raza: petRaza.trim() || 'Mestizo',
        edad: petEdad.trim() || '1 año',
        pesoKg: pesoNum > 0 ? pesoNum : 5,
        sexo: petSexo,
        color: 'No especificado',
      },
    });
    onClose();
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-[1px] p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-agendar-titulo"
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-white rounded-xl border border-slate-200 shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 sticky top-0 bg-white z-10">
          <div>
            <h2
              id="modal-agendar-titulo"
              className="text-lg font-semibold text-slate-900"
            >
              Agendar consulta
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Registrá un nuevo turno médico para un paciente existente o nuevo.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar ventana"
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors focus-visible:outline-2 focus-visible:outline-teal-600"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Selección de paciente */}
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-4">
              <label className="text-sm font-medium text-slate-900">
                Paciente y propietario
              </label>
              <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => setModoPaciente('existente')}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    modoPaciente === 'existente'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Paciente registrado
                </button>
                <button
                  type="button"
                  onClick={() => setModoPaciente('nuevo')}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    modoPaciente === 'nuevo'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Nuevo paciente
                </button>
              </div>
            </div>

            {modoPaciente === 'existente' ? (
              <div className="space-y-2">
                <select
                  aria-label="Seleccionar mascota"
                  value={mascotaId}
                  onChange={(e) => setMascotaId(e.target.value)}
                  className="w-full px-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-teal-600 focus:ring-1 focus:ring-teal-600"
                >
                  {visibleMascotas.length === 0 && (
                    <option value="">No tenés mascotas cargadas todavía</option>
                  )}
                  {visibleMascotas.map((m) => {
                    const prop = ownerMap.get(m.propietarioId);
                    return (
                      <option key={m.id} value={m.id}>
                        {m.nombre} ({m.especie} · {m.raza})
                        {!isClienta ? ` — Tutor: ${prop?.nombre ?? 'Sin asignar'}` : ''}
                      </option>
                    );
                  })}
                </select>
                {selectedPet && selectedPetOwner && (
                  <p className="text-xs text-slate-500">
                    Propietario: <span className="font-medium text-slate-700">{selectedPetOwner.nombre}</span>
                    <span className="mx-1.5" aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">{selectedPetOwner.telefono}</span>
                    {selectedPet.alergias && selectedPet.alergias !== 'Ninguna conocida' && (
                      <>
                        <span className="mx-1.5" aria-hidden="true">·</span>
                        <span className="text-amber-700 font-medium">
                          Alergia: {selectedPet.alergias}
                        </span>
                      </>
                    )}
                  </p>
                )}
              </div>
            ) : (
              <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Nombre de la mascota *
                    </label>
                    <input
                      type="text"
                      value={petNombre}
                      onChange={(e) => setPetNombre(e.target.value)}
                      placeholder="Ej. Rocco"
                      className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Especie
                      </label>
                      <select
                        value={petEspecie}
                        onChange={(e) => setPetEspecie(e.target.value as Especie)}
                        className="w-full px-2.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                      >
                        {ESPECIES.map((esp) => (
                          <option key={esp} value={esp}>
                            {esp}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Sexo
                      </label>
                      <select
                        value={petSexo}
                        onChange={(e) => setPetSexo(e.target.value as SexoMascota)}
                        className="w-full px-2.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                      >
                        <option value="Macho">Macho</option>
                        <option value="Hembra">Hembra</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-700 mb-1">
                      Raza
                    </label>
                    <input
                      type="text"
                      value={petRaza}
                      onChange={(e) => setPetRaza(e.target.value)}
                      placeholder="Ej. Mestizo"
                      className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Edad
                      </label>
                      <input
                        type="text"
                        value={petEdad}
                        onChange={(e) => setPetEdad(e.target.value)}
                        placeholder="Ej. 2 años"
                        className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Peso (kg)
                      </label>
                      <input
                        type="text"
                        value={petPeso}
                        onChange={(e) => setPetPeso(e.target.value)}
                        placeholder="Ej. 12.5"
                        className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono tabular-nums focus:outline-none focus:border-teal-600"
                      />
                    </div>
                  </div>
                </div>

                {!isClienta ? (
                <div className="pt-3 border-t border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-slate-700">
                      Datos del propietario
                    </span>
                    {propietarios.length > 0 && (
                      <div className="inline-flex items-center gap-3 text-xs">
                        <button
                          type="button"
                          onClick={() => setOwnerMode('nuevo')}
                          className={`font-medium ${
                            ownerMode === 'nuevo'
                              ? 'text-teal-700 underline underline-offset-4'
                              : 'text-slate-500 hover:text-slate-800'
                          }`}
                        >
                          Nuevo propietario
                        </button>
                        <button
                          type="button"
                          onClick={() => setOwnerMode('existente')}
                          className={`font-medium ${
                            ownerMode === 'existente'
                              ? 'text-teal-700 underline underline-offset-4'
                              : 'text-slate-500 hover:text-slate-800'
                          }`}
                        >
                          Propietario existente
                        </button>
                      </div>
                    )}
                  </div>

                  {ownerMode === 'existente' && propietarios.length > 0 ? (
                    <select
                      value={existingOwnerId}
                      onChange={(e) => setExistingOwnerId(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                    >
                      {propietarios.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.nombre} · {p.telefono}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Nombre completo *
                        </label>
                        <input
                          type="text"
                          value={ownerNombre}
                          onChange={(e) => setOwnerNombre(e.target.value)}
                          placeholder="Ej. Laura Giménez"
                          className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Teléfono *
                        </label>
                        <input
                          type="tel"
                          value={ownerTelefono}
                          onChange={(e) => setOwnerTelefono(e.target.value)}
                          placeholder="+54 11 ..."
                          className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono focus:outline-none focus:border-teal-600"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Correo electrónico
                        </label>
                        <input
                          type="email"
                          value={ownerEmail}
                          onChange={(e) => setOwnerEmail(e.target.value)}
                          placeholder="correo@ejemplo.com"
                          className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-slate-700 mb-1">
                          Dirección
                        </label>
                        <input
                          type="text"
                          value={ownerDireccion}
                          onChange={(e) => setOwnerDireccion(e.target.value)}
                          placeholder="Calle y altura"
                          className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                        />
                      </div>
                    </div>
                  )}
                </div>
                ) : (
                  <p className="text-xs text-slate-600 pt-2 border-t border-slate-200">
                    La mascota quedará registrada a nombre de{' '}
                    <span className="font-medium text-slate-900">
                      {currentUser?.nombre}
                    </span>
                    .
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Datos del turno */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-slate-200">
            <div>
              <label
                htmlFor="turno-fecha"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Fecha *
              </label>
              <input
                id="turno-fecha"
                type="date"
                value={fecha}
                onChange={(e) => setFecha(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono tabular-nums focus:outline-none focus:border-teal-600"
              />
            </div>

            <div>
              <label
                htmlFor="turno-hora"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Horario *
              </label>
              <select
                id="turno-hora"
                value={hora}
                onChange={(e) => setHora(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono tabular-nums focus:outline-none focus:border-teal-600"
              >
                {HORARIOS_DISPONIBLES.map((slot) => {
                  const busy = occupiedSlots.has(slot);
                  return (
                    <option key={slot} value={slot}>
                      {slot} {busy ? '(Ocupado)' : ''}
                    </option>
                  );
                })}
              </select>
            </div>

            <div>
              <label
                htmlFor="turno-estado"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Estado inicial
              </label>
              {isClienta ? (
                <input
                  id="turno-estado"
                  type="text"
                  readOnly
                  value="Pendiente de confirmación"
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-600"
                />
              ) : (
                <select
                  id="turno-estado"
                  value={estadoInicial}
                  onChange={(e) => setEstadoInicial(e.target.value as EstadoTurno)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                >
                  <option value="Pendiente">Pendiente</option>
                  <option value="Confirmado">Confirmado</option>
                </select>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="turno-tipo"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Tipo de atención
              </label>
              <select
                id="turno-tipo"
                value={tipo}
                onChange={(e) => setTipo(e.target.value as TipoConsulta)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
              >
                {TIPOS_CONSULTA.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="turno-vet"
                className="block text-xs font-medium text-slate-700 mb-1.5"
              >
                Profesional asignado
              </label>
              <select
                id="turno-vet"
                value={veterinario}
                onChange={(e) => setVeterinario(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
              >
                {VETERINARIOS.map((v) => (
                  <option key={v} value={v}>
                    {v}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label
              htmlFor="turno-motivo"
              className="block text-xs font-medium text-slate-700 mb-1.5"
            >
              Motivo de la consulta *
            </label>
            <input
              id="turno-motivo"
              type="text"
              value={motivo}
              onChange={(e) => setMotivo(e.target.value)}
              placeholder="Ej. Vacunación anual, control de peso, decaimiento..."
              className="w-full px-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
            />
          </div>

          <div>
            <label
              htmlFor="turno-obs"
              className="block text-xs font-medium text-slate-700 mb-1.5"
            >
              Observaciones previas (opcional)
            </label>
            <textarea
              id="turno-obs"
              rows={2}
              value={observaciones}
              onChange={(e) => setObservaciones(e.target.value)}
              placeholder="Indicaciones para el profesional o preparación previa..."
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg resize-none focus:outline-none focus:border-teal-600"
            />
          </div>

          {error && (
            <p
              role="alert"
              className="text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2"
            >
              {error}
            </p>
          )}

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
            >
              Confirmar turno
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
