import { useEffect } from 'react';
import { CalendarPlus, Mail, Phone, X } from 'lucide-react';
import {
  EstadoTurno,
  Mascota,
  Propietario,
  Turno,
} from '../types/veterinaria';
import { formatFechaCorta } from '../utils/formatters';
import { PetAvatar } from './PetAvatar';
import { StatusSelector, StatusText } from './StatusControl';

interface PetDetailDrawerProps {
  mascota: Mascota | null;
  propietario?: Propietario;
  turnos: Turno[];
  isAdmin: boolean;
  onClose: () => void;
  onBookForPet: (mascotaId: string) => void;
  onChangeStatus: (turnoId: string, nuevoEstado: EstadoTurno) => void;
  onSelectTurno: (turnoId: string) => void;
}

export function PetDetailDrawer({
  mascota,
  propietario,
  turnos,
  isAdmin,
  onClose,
  onBookForPet,
  onChangeStatus,
  onSelectTurno,
}: PetDetailDrawerProps) {
  useEffect(() => {
    if (!mascota) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [mascota, onClose]);

  if (!mascota) return null;

  const petTurnos = [...turnos]
    .filter((t) => t.mascotaId === mascota.id)
    .sort((a, b) => `${b.fecha} ${b.hora}`.localeCompare(`${a.fecha} ${a.hora}`));

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-900/30 backdrop-blur-[1px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="drawer-mascota-titulo"
      onClick={onClose}
    >
      <aside
        className="w-full max-w-lg h-full bg-white border-l border-slate-200 shadow-xl flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <h2
            id="drawer-mascota-titulo"
            className="text-lg font-semibold text-slate-900"
          >
            Ficha del paciente
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar ficha"
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100"
          >
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Cabecera del paciente */}
          <div className="flex items-start gap-4">
            <PetAvatar
              nombre={mascota.nombre}
              especie={mascota.especie}
              fotoUrl={mascota.fotoUrl}
              size="lg"
            />
            <div className="min-w-0 flex-1">
              <h3 className="text-xl font-semibold text-slate-900">
                {mascota.nombre}
              </h3>
              <p className="text-sm text-slate-600 mt-0.5">
                {mascota.especie}
                <span className="mx-1.5" aria-hidden="true">·</span>
                {mascota.raza}
              </p>
              <div className="mt-3">
                <button
                  type="button"
                  onClick={() => onBookForPet(mascota.id)}
                  className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap"
                >
                  <CalendarPlus size={14} />
                  <span>Agendar consulta</span>
                </button>
              </div>
            </div>
          </div>

          {/* Datos clínicos */}
          <dl className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 border-y border-slate-200">
            <div>
              <dt className="text-xs text-slate-500">Edad</dt>
              <dd className="text-sm font-medium text-slate-900 mt-0.5">
                {mascota.edad}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Peso</dt>
              <dd className="text-sm font-medium text-slate-900 font-mono tabular-nums mt-0.5">
                {mascota.pesoKg} kg
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Sexo</dt>
              <dd className="text-sm font-medium text-slate-900 mt-0.5">
                {mascota.sexo}
              </dd>
            </div>
            <div>
              <dt className="text-xs text-slate-500">Pelaje</dt>
              <dd className="text-sm font-medium text-slate-900 mt-0.5 truncate">
                {mascota.color}
              </dd>
            </div>
          </dl>

          {mascota.alergias && (
            <div>
              <p className="text-xs font-medium text-slate-500 mb-1">
                Alergias y consideraciones
              </p>
              <p className="text-sm text-slate-800">{mascota.alergias}</p>
            </div>
          )}

          {/* Propietario */}
          {propietario && (
            <section className="space-y-2 pt-2 border-t border-slate-200">
              <p className="text-xs font-medium text-slate-500">
                Propietario responsable
              </p>
              <p className="text-sm font-semibold text-slate-900">
                {propietario.nombre}
              </p>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-600">
                <span className="inline-flex items-center gap-1.5 font-mono tabular-nums">
                  <Phone size={13} className="text-slate-400" />
                  {propietario.telefono}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Mail size={13} className="text-slate-400" />
                  {propietario.email}
                </span>
              </div>
            </section>
          )}

          {/* Historial de turnos */}
          <section className="space-y-3 pt-2 border-t border-slate-200">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-medium text-slate-500">
                Historial y próximos turnos ({petTurnos.length})
              </h4>
            </div>

            {petTurnos.length === 0 ? (
              <p className="text-sm text-slate-500 py-4">
                Esta mascota aún no tiene turnos registrados.
              </p>
            ) : (
              <ul className="divide-y divide-slate-200 border border-slate-200 rounded-lg bg-white">
                {petTurnos.map((t) => (
                  <li
                    key={t.id}
                    onClick={() => onSelectTurno(t.id)}
                    className="p-3.5 hover:bg-slate-50 transition-colors cursor-pointer space-y-2"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="text-xs text-slate-600 font-mono tabular-nums">
                        {formatFechaCorta(t.fecha)} · {t.hora} hs
                      </div>
                      {isAdmin ? (
                        <StatusSelector
                          estado={t.estado}
                          onChange={(est) => onChangeStatus(t.id, est)}
                        />
                      ) : (
                        <StatusText estado={t.estado} />
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-slate-900">
                        {t.motivo}
                      </p>
                      <p className="text-xs text-slate-500 mt-0.5">
                        {t.tipo} · {t.veterinario}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </aside>
    </div>
  );
}
