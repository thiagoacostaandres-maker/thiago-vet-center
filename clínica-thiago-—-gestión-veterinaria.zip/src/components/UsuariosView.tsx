import { useState } from 'react';
import {
  CalendarPlus,
  Lock,
  LogIn,
  LogOut,
  PawPrint,
  ShieldCheck,
  UserPlus,
  Users,
} from 'lucide-react';
import {
  EstadoTurno,
  Mascota,
  Propietario,
  Turno,
  Usuario,
} from '../types/veterinaria';
import { formatFechaCorta } from '../utils/formatters';
import { PetAvatar } from './PetAvatar';
import { StatusSelector, StatusText } from './StatusControl';
import { PropietariosView } from './PropietariosView';

interface UsuariosViewProps {
  currentUser: Usuario | null;
  preferredAccessPanel: 'clienta' | 'admin';
  pendingBookingNotice: boolean;
  propietarios: Propietario[];
  mascotas: Mascota[];
  turnos: Turno[];
  onLoginClient: (email: string) => { ok: boolean; error?: string };
  onRegisterClient: (payload: {
    nombre: string;
    email: string;
    telefono: string;
  }) => { ok: boolean; error?: string };
  onLoginAdmin: (password: string) => { ok: boolean; error?: string };
  onLogout: () => void;
  onSelectPet: (mascotaId: string) => void;
  onBookForPet: (mascotaId?: string) => void;
  onChangeTurnoStatus: (turnoId: string, estado: EstadoTurno) => void;
  onOpenNewOwnerModal: () => void;
  onOpenNewPetForOwner: (ownerId: string) => void;
  onGoToTurnos: () => void;
}

export function UsuariosView({
  currentUser,
  preferredAccessPanel,
  pendingBookingNotice,
  propietarios,
  mascotas,
  turnos,
  onLoginClient,
  onRegisterClient,
  onLoginAdmin,
  onLogout,
  onSelectPet,
  onBookForPet,
  onChangeTurnoStatus,
  onOpenNewOwnerModal,
  onOpenNewPetForOwner,
  onGoToTurnos,
}: UsuariosViewProps) {
  const [clientAuthTab, setClientAuthTab] = useState<'login' | 'register'>(
    'login'
  );
  const [adminSubView, setAdminSubView] = useState<'resumen' | 'propietarios'>(
    'resumen'
  );

  // Formulario Clienta — Login
  const [loginEmail, setLoginEmail] = useState('');
  const [clientError, setClientError] = useState('');

  // Formulario Clienta — Registro
  const [regNombre, setRegNombre] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regTelefono, setRegTelefono] = useState('');

  // Formulario Administrador — Contraseña
  const [adminPass, setAdminPass] = useState('');
  const [adminError, setAdminError] = useState('');

  function handleAdminSubmit(e: React.FormEvent) {
    e.preventDefault();
    setAdminError('');
    if (!adminPass) {
      setAdminError('Ingresá la contraseña de administrador.');
      return;
    }
    const res = onLoginAdmin(adminPass);
    if (!res.ok) {
      setAdminError(res.error || 'Contraseña incorrecta.');
    } else {
      setAdminPass('');
    }
  }

  function handleClientLoginSubmit(e: React.FormEvent) {
    e.preventDefault();
    setClientError('');
    if (!loginEmail.trim()) {
      setClientError('Ingresá tu correo electrónico.');
      return;
    }
    const res = onLoginClient(loginEmail.trim());
    if (!res.ok) {
      setClientError(res.error || 'No se encontró una cuenta con ese correo.');
    }
  }

  function handleClientRegisterSubmit(e: React.FormEvent) {
    e.preventDefault();
    setClientError('');
    if (!regNombre.trim() || !regEmail.trim() || !regTelefono.trim()) {
      setClientError('Completá nombre, correo y teléfono.');
      return;
    }
    const res = onRegisterClient({
      nombre: regNombre.trim(),
      email: regEmail.trim(),
      telefono: regTelefono.trim(),
    });
    if (!res.ok) {
      setClientError(res.error || 'No se pudo crear la cuenta.');
    } else {
      setRegNombre('');
      setRegEmail('');
      setRegTelefono('');
    }
  }

  // Estado 1: Nadie inició sesión -> Mostrar los 2 apartados sin contraseña
  if (!currentUser) {
    return (
      <div className="space-y-8">
        <div className="max-w-2xl space-y-1.5">
          <p className="text-xs font-medium text-teal-700">
            Acceso a la plataforma
          </p>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">
            Ingresá como clienta o administrador
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Elegí el apartado correspondiente: las clientas pueden registrarse o
            ingresar con su correo para agendar consultas, y la administración
            accede directamente al panel de gestión.
          </p>
        </div>

        {pendingBookingNotice && (
          <div className="p-4 rounded-xl bg-teal-50 border border-teal-200 text-sm text-teal-900">
            Para reservar un turno, primero ingresá o registrate en el{' '}
            <span className="font-semibold">Apartado Clienta</span>.
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* APARTADO 1: CLIENTA (Registro e inicio de sesión para agendar) */}
          <section
            aria-labelledby="titulo-apartado-clienta"
            className={`lg:col-span-7 bg-white rounded-xl p-6 sm:p-8 space-y-6 border ${
              preferredAccessPanel === 'clienta'
                ? 'border-teal-600'
                : 'border-slate-200'
            }`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <p className="text-xs font-medium text-teal-700">
                  Apartado 01 · Pacientes y tutores
                </p>
                <h2
                  id="titulo-apartado-clienta"
                  className="text-xl font-semibold text-slate-900 mt-0.5"
                >
                  Portal de Clienta
                </h2>
                <p className="text-xs text-slate-500 mt-1">
                  Ingresá con tu correo o creá tu perfil para agendar citas.
                </p>
              </div>

              <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg self-start sm:self-auto">
                <button
                  type="button"
                  onClick={() => {
                    setClientAuthTab('login');
                    setClientError('');
                  }}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    clientAuthTab === 'login'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <LogIn size={13} />
                  <span>Iniciar sesión</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setClientAuthTab('register');
                    setClientError('');
                  }}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    clientAuthTab === 'register'
                      ? 'bg-white text-slate-900 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <UserPlus size={13} />
                  <span>Registrarme</span>
                </button>
              </div>
            </div>

            {clientAuthTab === 'login' ? (
              <form onSubmit={handleClientLoginSubmit} className="space-y-4">
                <div>
                  <label
                    htmlFor="client-login-email"
                    className="block text-xs font-medium text-slate-700 mb-1"
                  >
                    Correo electrónico
                  </label>
                  <input
                    id="client-login-email"
                    type="email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    placeholder="camila.rodriguez@correo.com"
                    className="w-full px-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>

                {clientError && (
                  <p
                    role="alert"
                    className="text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2"
                  >
                    {clientError}
                  </p>
                )}

                <div className="pt-2 flex flex-wrap items-center gap-3">
                  <button
                    type="submit"
                    className="px-5 py-2.5 text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap"
                  >
                    Ingresar como clienta
                  </button>
                  <button
                    type="button"
                    onClick={() => onLoginClient('camila.rodriguez@correo.com')}
                    className="px-4 py-2.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
                  >
                    Ingresar como Camila Rodríguez
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleClientRegisterSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label
                      htmlFor="client-reg-nombre"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Nombre y apellido *
                    </label>
                    <input
                      id="client-reg-nombre"
                      type="text"
                      value={regNombre}
                      onChange={(e) => setRegNombre(e.target.value)}
                      placeholder="Ej. Valentina Gómez"
                      className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="client-reg-email"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Correo electrónico *
                    </label>
                    <input
                      id="client-reg-email"
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="nombre@correo.com"
                      className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="client-reg-tel"
                      className="block text-xs font-medium text-slate-700 mb-1"
                    >
                      Teléfono *
                    </label>
                    <input
                      id="client-reg-tel"
                      type="tel"
                      value={regTelefono}
                      onChange={(e) => setRegTelefono(e.target.value)}
                      placeholder="+54 11 ..."
                      className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono focus:outline-none focus:border-teal-600"
                    />
                  </div>
                </div>

                {clientError && (
                  <p
                    role="alert"
                    className="text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2"
                  >
                    {clientError}
                  </p>
                )}

                <div className="pt-2">
                  <button
                    type="submit"
                    className="px-5 py-2.5 text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap"
                  >
                    Registrarme y agendar
                  </button>
                </div>
              </form>
            )}
          </section>

          {/* APARTADO 2: ADMINISTRADOR (Ingreso con contraseña) */}
          <section
            aria-labelledby="titulo-apartado-admin"
            className={`lg:col-span-5 bg-white rounded-xl p-6 sm:p-8 space-y-5 border ${
              preferredAccessPanel === 'admin'
                ? 'border-slate-900'
                : 'border-slate-200'
            }`}
          >
            <div className="border-b border-slate-100 pb-4 space-y-1">
              <div className="flex items-center gap-2 text-xs font-medium text-slate-600">
                <Lock size={14} className="text-slate-700" />
                <span>Apartado 02 · Gestión clínica</span>
              </div>
              <h2
                id="titulo-apartado-admin"
                className="text-xl font-semibold text-slate-900"
              >
                Acceso Administrador
              </h2>
              <p className="text-xs text-slate-500 leading-relaxed">
                Ingresá con la contraseña de administración para ver toda la
                agenda, administrar propietarios y cambiar el estado de los
                turnos.
              </p>
            </div>

            <form onSubmit={handleAdminSubmit} className="space-y-4">
              <div>
                <label
                  htmlFor="admin-password"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Contraseña de administrador *
                </label>
                <input
                  id="admin-password"
                  type="password"
                  value={adminPass}
                  onChange={(e) => setAdminPass(e.target.value)}
                  placeholder="Ingresá la contraseña"
                  className="w-full px-3 py-2.5 text-sm bg-white border border-slate-300 rounded-lg font-mono focus:outline-none focus:border-slate-900"
                />
              </div>

              {adminError && (
                <p
                  role="alert"
                  className="text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2"
                >
                  {adminError}
                </p>
              )}

              <button
                type="submit"
                className="w-full inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap"
              >
                <ShieldCheck size={16} />
                <span>Entrar como administrador</span>
              </button>
            </form>
          </section>
        </div>
      </div>
    );
  }

  // Estado 2: Sesión iniciada como CLIENTA
  if (currentUser.rol === 'Clienta') {
    const myPets = currentUser.propietarioId
      ? mascotas.filter((m) => m.propietarioId === currentUser.propietarioId)
      : [];
    const myTurnos = currentUser.propietarioId
      ? turnos.filter((t) => t.propietarioId === currentUser.propietarioId)
      : [];

    return (
      <div className="space-y-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <p className="text-xs font-medium text-teal-700">
              Portal de Clienta
            </p>
            <h1 className="text-2xl font-semibold text-slate-900">
              {currentUser.nombre}
            </h1>
            <p className="text-xs text-slate-500 font-mono tabular-nums">
              {currentUser.email} · {currentUser.telefono}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => onBookForPet(myPets[0]?.id)}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap"
            >
              <CalendarPlus size={14} />
              <span>Agendar consulta</span>
            </button>
            <button
              type="button"
              onClick={onLogout}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
            >
              <LogOut size={14} />
              <span>Cambiar de cuenta</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-900">
                Mis mascotas ({myPets.length})
              </h2>
              {currentUser.propietarioId && (
                <button
                  type="button"
                  onClick={() =>
                    onOpenNewPetForOwner(currentUser.propietarioId!)
                  }
                  className="text-xs font-medium text-teal-700 hover:underline underline-offset-4"
                >
                  + Agregar mascota
                </button>
              )}
            </div>

            {myPets.length === 0 ? (
              <div className="py-6 text-center space-y-2">
                <PawPrint size={24} className="mx-auto text-slate-300" />
                <p className="text-xs text-slate-500">
                  Todavía no registraste mascotas. Podés sumar una ahora o al
                  agendar tu primer turno.
                </p>
              </div>
            ) : (
              <ul className="divide-y divide-slate-100">
                {myPets.map((pet) => (
                  <li
                    key={pet.id}
                    onClick={() => onSelectPet(pet.id)}
                    className="py-3 flex items-center justify-between gap-3 cursor-pointer hover:bg-slate-50 -mx-2 px-2 rounded-lg transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <PetAvatar
                        nombre={pet.nombre}
                        especie={pet.especie}
                        fotoUrl={pet.fotoUrl}
                        size="sm"
                      />
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-900 truncate">
                          {pet.nombre}
                        </p>
                        <p className="text-xs text-slate-500 truncate">
                          {pet.especie} · {pet.raza}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onBookForPet(pet.id);
                      }}
                      className="text-xs font-medium text-teal-700 hover:text-teal-900 whitespace-nowrap"
                    >
                      Agendar
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-900">
                Mis turnos agendados ({myTurnos.length})
              </h2>
              <button
                type="button"
                onClick={onGoToTurnos}
                className="text-xs font-medium text-teal-700 hover:underline underline-offset-4"
              >
                Ir a Turnos
              </button>
            </div>

            {myTurnos.length === 0 ? (
              <p className="text-sm text-slate-500 py-4">
                Aún no tenés turnos agendados.
              </p>
            ) : (
              <ul className="divide-y divide-slate-200">
                {myTurnos.map((t) => {
                  const pet = mascotas.find((m) => m.id === t.mascotaId);
                  return (
                    <li
                      key={t.id}
                      className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                      <div>
                        <p className="text-sm font-medium text-slate-900">
                          {pet?.nombre ?? 'Mascota'} · {t.motivo}
                        </p>
                        <p className="text-xs text-slate-500 font-mono tabular-nums mt-0.5">
                          {formatFechaCorta(t.fecha)} · {t.hora} hs ·{' '}
                          {t.veterinario}
                        </p>
                      </div>
                      <div className="flex items-center gap-3">
                        <StatusText estado={t.estado} />
                        {(t.estado === 'Pendiente' ||
                          t.estado === 'Confirmado') && (
                          <button
                            type="button"
                            onClick={() =>
                              onChangeTurnoStatus(t.id, 'Cancelado')
                            }
                            className="text-xs font-medium text-slate-500 hover:text-rose-700 whitespace-nowrap"
                          >
                            Cancelar
                          </button>
                        )}
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Estado 3: Sesión iniciada como ADMINISTRADOR
  return (
    <div className="space-y-6">
      <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-medium text-slate-700">
            <ShieldCheck size={15} className="text-teal-700" />
            <span>Panel de Administración</span>
          </div>
          <h1 className="text-2xl font-semibold text-slate-900">
            {currentUser.nombre}
          </h1>
          <p className="text-xs text-slate-500">
            Control completo de turnos, estados clínicos, mascotas y propietarios.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setAdminSubView('resumen')}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                adminSubView === 'resumen'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Resumen de gestión
            </button>
            <button
              type="button"
              onClick={() => setAdminSubView('propietarios')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                adminSubView === 'propietarios'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Users size={13} />
              <span>Propietarios ({propietarios.length})</span>
            </button>
          </div>

          <button
            type="button"
            onClick={onLogout}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
          >
            <LogOut size={14} />
            <span>Cambiar de cuenta</span>
          </button>
        </div>
      </div>

      {adminSubView === 'propietarios' ? (
        <PropietariosView
          propietarios={propietarios}
          mascotas={mascotas}
          turnos={turnos}
          onSelectPet={onSelectPet}
          onBookForPet={(id) => onBookForPet(id)}
          onOpenNewOwnerModal={onOpenNewOwnerModal}
          onOpenNewPetForOwner={onOpenNewPetForOwner}
        />
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <h2 className="text-base font-semibold text-slate-900">
              Últimos turnos de la clínica ({turnos.length})
            </h2>
            <button
              type="button"
              onClick={onGoToTurnos}
              className="text-xs font-medium text-teal-700 hover:underline underline-offset-4 self-start sm:self-auto"
            >
              Abrir agenda completa en Turnos
            </button>
          </div>

          <ul className="divide-y divide-slate-200">
            {turnos.slice(0, 6).map((t) => {
              const pet = mascotas.find((m) => m.id === t.mascotaId);
              const owner = propietarios.find((p) => p.id === t.propietarioId);
              return (
                <li
                  key={t.id}
                  className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div>
                    <p className="text-sm font-medium text-slate-900">
                      {pet?.nombre ?? 'Mascota'} · {t.motivo}
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Tutor: {owner?.nombre ?? '—'} ·{' '}
                      <span className="font-mono tabular-nums">
                        {formatFechaCorta(t.fecha)} · {t.hora} hs
                      </span>
                    </p>
                  </div>
                  <StatusSelector
                    estado={t.estado}
                    onChange={(est) => onChangeTurnoStatus(t.id, est)}
                  />
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
