import { useState } from 'react';
import { Clock, Mail, MapPin, Phone, Send } from 'lucide-react';

export function ContactoView() {
  const [nombre, setNombre] = useState('');
  const [contacto, setContacto] = useState('');
  const [mensaje, setMensaje] = useState('');
  const [error, setError] = useState('');
  const [sent, setSent] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    if (!nombre.trim() || !contacto.trim() || !mensaje.trim()) {
      setError('Completá tu nombre, correo o teléfono y tu consulta.');
      return;
    }

    setSent(true);
    setNombre('');
    setContacto('');
    setMensaje('');
  }

  return (
    <div className="space-y-8">
      <div className="max-w-2xl space-y-2">
        <p className="text-xs font-medium text-teal-700">Atención al tutor</p>
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">
          Ubicación y medios de contacto
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          Comunicate con recepción para consultas sobre estudios previos,
          presupuestos quirúrgicos o indicaciones antes de tu visita.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Datos de ubicación y canales */}
        <div className="lg:col-span-5 space-y-6 bg-white border border-slate-200 rounded-xl p-6">
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <MapPin size={18} className="text-teal-700 shrink-0 mt-0.5" />
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  Dirección de la clínica
                </h2>
                <p className="text-sm text-slate-600 mt-0.5">
                  Av. Santa Fe 3420, Palermo
                </p>
                <p className="text-xs text-slate-500 mt-0.5">
                  Ciudad Autónoma de Buenos Aires · A dos cuadras de Plaza Italia
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 pt-3 border-t border-slate-100">
              <Phone size={18} className="text-teal-700 shrink-0 mt-0.5" />
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  Teléfonos y WhatsApp
                </h2>
                <p className="text-sm text-slate-700 font-mono tabular-nums mt-0.5">
                  +54 11 4800-2210
                </p>
                <p className="text-xs text-slate-500 font-mono tabular-nums mt-0.5">
                  Urgencias: +54 11 5912-8840
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 pt-3 border-t border-slate-100">
              <Mail size={18} className="text-teal-700 shrink-0 mt-0.5" />
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  Correo electrónico
                </h2>
                <p className="text-sm text-slate-700 mt-0.5">
                  recepcion@clinicathiago.com
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 pt-3 border-t border-slate-100">
              <Clock size={18} className="text-teal-700 shrink-0 mt-0.5" />
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  Horarios de atención
                </h2>
                <p className="text-sm text-slate-600 font-mono tabular-nums mt-0.5">
                  Lunes a viernes: 09:00 a 19:30 hs
                </p>
                <p className="text-sm text-slate-600 font-mono tabular-nums">
                  Sábados: 09:30 a 14:30 hs
                </p>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 text-xs text-slate-500 leading-relaxed">
            Contamos con acceso a nivel para carros transportadores y
            estacionamiento de cortesía de 15 minutos frente a la entrada
            principal.
          </div>
        </div>

        {/* Formulario de consulta */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
          <h2 className="text-lg font-semibold text-slate-900">
            Enviar un mensaje
          </h2>
          <p className="text-xs text-slate-500 mt-1 mb-6">
            Respondemos consultas administrativas y médicas dentro del horario
            de atención.
          </p>

          {sent ? (
            <div className="p-6 rounded-lg bg-teal-50 border border-teal-200 space-y-3">
              <p className="text-sm font-semibold text-teal-900">
                Mensaje recibido en Clínica Thiago
              </p>
              <p className="text-xs text-teal-800 leading-relaxed">
                Nuestro equipo de recepción te responderá a la brevedad por el
                medio de contacto que indicaste.
              </p>
              <button
                type="button"
                onClick={() => setSent(false)}
                className="px-3.5 py-1.5 text-xs font-medium text-teal-900 bg-white border border-teal-300 rounded-md hover:bg-teal-100"
              >
                Enviar otra consulta
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="contact-nombre"
                    className="block text-xs font-medium text-slate-700 mb-1"
                  >
                    Tu nombre *
                  </label>
                  <input
                    id="contact-nombre"
                    type="text"
                    value={nombre}
                    onChange={(e) => setNombre(e.target.value)}
                    placeholder="Nombre y apellido"
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>

                <div>
                  <label
                    htmlFor="contact-info"
                    className="block text-xs font-medium text-slate-700 mb-1"
                  >
                    Teléfono o correo *
                  </label>
                  <input
                    id="contact-info"
                    type="text"
                    value={contacto}
                    onChange={(e) => setContacto(e.target.value)}
                    placeholder="+54 11 ... o correo@..."
                    className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="contact-msg"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Mensaje *
                </label>
                <textarea
                  id="contact-msg"
                  rows={4}
                  value={mensaje}
                  onChange={(e) => setMensaje(e.target.value)}
                  placeholder="Contanos en qué podemos ayudarte o sobre qué mascota consultás..."
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg resize-none focus:outline-none focus:border-teal-600"
                />
              </div>

              {error && (
                <p
                  role="alert"
                  className="text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2"
                >
                  {error}
                </p>
              )}

              <div className="pt-1">
                <button
                  type="submit"
                  className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap"
                >
                  <Send size={15} />
                  <span>Enviar mensaje</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
