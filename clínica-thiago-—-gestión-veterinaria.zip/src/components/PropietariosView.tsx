import { useMemo, useState } from 'react';
import { CalendarPlus, Plus, Search } from 'lucide-react';
import { Mascota, Propietario, Turno } from '../types/veterinaria';

interface PropietariosViewProps {
  propietarios: Propietario[];
  mascotas: Mascota[];
  turnos: Turno[];
  onSelectPet: (mascotaId: string) => void;
  onBookForPet: (mascotaId: string) => void;
  onOpenNewOwnerModal: () => void;
  onOpenNewPetForOwner: (ownerId: string) => void;
}

export function PropietariosView({
  propietarios,
  mascotas,
  turnos,
  onSelectPet,
  onBookForPet,
  onOpenNewOwnerModal,
  onOpenNewPetForOwner,
}: PropietariosViewProps) {
  const [search, setSearch] = useState('');

  const petsByOwner = useMemo(() => {
    const map = new Map<string, Mascota[]>();
    for (const m of mascotas) {
      const list = map.get(m.propietarioId) ?? [];
      list.push(m);
      map.set(m.propietarioId, list);
    }
    return map;
  }, [mascotas]);

  const activeTurnosCountByOwner = useMemo(() => {
    const map = new Map<string, number>();
    for (const t of turnos) {
      if (t.estado !== 'Cancelado' && t.estado !== 'Completado') {
        map.set(t.propietarioId, (map.get(t.propietarioId) ?? 0) + 1);
      }
    }
    return map;
  }, [turnos]);

  const filteredOwners = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return propietarios;
    return propietarios.filter((p) => {
      const pets = petsByOwner.get(p.id) ?? [];
      return (
        p.nombre.toLowerCase().includes(q) ||
        p.telefono.toLowerCase().includes(q) ||
        p.email.toLowerCase().includes(q) ||
        p.dni.toLowerCase().includes(q) ||
        pets.some((m) => m.nombre.toLowerCase().includes(q))
      );
    });
  }, [propietarios, search, petsByOwner]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900">
            Propietarios
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Tutores registrados, datos de contacto y mascotas bajo su cuidado.
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenNewOwnerModal}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-slate-800 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <Plus size={16} />
          <span>Nuevo propietario</span>
        </button>
      </div>

      {/* Búsqueda */}
      <div className="flex items-center justify-between gap-4">
        <p className="text-xs text-slate-500 font-mono tabular-nums">
          {filteredOwners.length} propietarios registrados
        </p>
        <div className="relative w-full sm:w-80">
          <Search
            size={15}
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por nombre, DNI, teléfono o mascota..."
            aria-label="Buscar propietarios"
            className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-200 rounded-lg placeholder:text-slate-400 focus:outline-none focus:border-teal-600"
          />
        </div>
      </div>

      {filteredOwners.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
          <p className="text-sm font-medium text-slate-900">
            No se encontraron propietarios con esa búsqueda.
          </p>
          <button
            type="button"
            onClick={onOpenNewOwnerModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800"
          >
            <Plus size={14} />
            <span>Registrar propietario</span>
          </button>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-500">
                  <th className="py-3 pl-5 pr-4 whitespace-nowrap">Propietario</th>
                  <th className="py-3 px-4 whitespace-nowrap">Contacto</th>
                  <th className="py-3 px-4">Domicilio</th>
                  <th className="py-3 px-4">Mascotas</th>
                  <th className="py-3 px-4 text-right whitespace-nowrap">
                    Turnos activos
                  </th>
                  <th className="py-3 pl-4 pr-5 text-right whitespace-nowrap">
                    Acciones
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-sm">
                {filteredOwners.map((owner) => {
                  const pets = petsByOwner.get(owner.id) ?? [];
                  const activeCount = activeTurnosCountByOwner.get(owner.id) ?? 0;

                  return (
                    <tr key={owner.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 pl-5 pr-4 align-top">
                        <div className="font-medium text-slate-900">
                          {owner.nombre}
                        </div>
                        <div className="text-xs text-slate-500 font-mono tabular-nums mt-0.5">
                          DNI {owner.dni}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 align-top">
                        <div className="text-xs font-mono tabular-nums text-slate-800">
                          {owner.telefono}
                        </div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          {owner.email}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 align-top text-xs text-slate-600 max-w-xs">
                        <div>{owner.direccion}</div>
                        {owner.notas && (
                          <div className="text-slate-400 mt-1 truncate">
                            {owner.notas}
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4 align-top">
                        {pets.length === 0 ? (
                          <span className="text-xs text-slate-400">Sin mascotas</span>
                        ) : (
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                            {pets.map((m, idx) => (
                              <span key={m.id} className="inline-flex items-center text-xs">
                                <button
                                  type="button"
                                  onClick={() => onSelectPet(m.id)}
                                  className="font-medium text-teal-700 hover:text-teal-900 hover:underline underline-offset-4"
                                >
                                  {m.nombre}
                                </button>
                                <span className="text-slate-400 ml-1">
                                  ({m.especie})
                                </span>
                                {idx < pets.length - 1 && (
                                  <span className="text-slate-300 ml-2" aria-hidden="true">
                                    ·
                                  </span>
                                )}
                              </span>
                            ))}
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4 align-top text-right font-mono tabular-nums text-slate-800">
                        {activeCount}
                      </td>

                      <td className="py-3.5 pl-4 pr-5 align-top text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => onOpenNewPetForOwner(owner.id)}
                            className="px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 rounded-md hover:bg-slate-50 whitespace-nowrap"
                          >
                            + Mascota
                          </button>
                          {pets[0] && (
                            <button
                              type="button"
                              onClick={() => onBookForPet(pets[0].id)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-teal-800 bg-teal-50 border border-teal-200 rounded-md hover:bg-teal-100 whitespace-nowrap"
                            >
                              <CalendarPlus size={13} />
                              <span>Agendar</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
