import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import {
  Especie,
  Mascota,
  Propietario,
  SexoMascota,
} from '../types/veterinaria';

interface NewPetModalProps {
  isOpen: boolean;
  onClose: () => void;
  propietarios: Propietario[];
  preselectedOwnerId?: string;
  lockOwner?: boolean;
  onCreatePet: (pet: Omit<Mascota, 'id'>) => void;
}

const ESPECIES: Especie[] = ['Perro', 'Gato', 'Conejo', 'Ave', 'Otro'];

export function NewPetModal({
  isOpen,
  onClose,
  propietarios,
  preselectedOwnerId,
  lockOwner = false,
  onCreatePet,
}: NewPetModalProps) {
  const [nombre, setNombre] = useState('');
  const [especie, setEspecie] = useState<Especie>('Perro');
  const [raza, setRaza] = useState('');
  const [edad, setEdad] = useState('');
  const [pesoKg, setPesoKg] = useState('');
  const [sexo, setSexo] = useState<SexoMascota>('Macho');
  const [color, setColor] = useState('');
  const [alergias, setAlergias] = useState('');
  const [propietarioId, setPropietarioId] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    setNombre('');
    setEspecie('Perro');
    setRaza('');
    setEdad('');
    setPesoKg('');
    setSexo('Macho');
    setColor('');
    setAlergias('');
    setPropietarioId(preselectedOwnerId || propietarios[0]?.id || '');
    setError('');
  }, [isOpen, preselectedOwnerId, propietarios]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!nombre.trim()) {
      setError('Ingresá el nombre de la mascota.');
      return;
    }
    if (!propietarioId) {
      setError('Seleccioná un propietario registrado.');
      return;
    }

    const parsedWeight = parseFloat(pesoKg.replace(',', '.'));
    onCreatePet({
      nombre: nombre.trim(),
      especie,
      raza: raza.trim() || 'Mestizo',
      edad: edad.trim() || '1 año',
      pesoKg: !isNaN(parsedWeight) && parsedWeight > 0 ? parsedWeight : 4.5,
      sexo,
      color: color.trim() || 'Sin especificar',
      propietarioId,
      alergias: alergias.trim() || 'Ninguna conocida',
    });
    onClose();
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-[1px] p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-mascota-titulo"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-white rounded-xl border border-slate-200 shadow-lg"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <div>
            <h2
              id="modal-mascota-titulo"
              className="text-lg font-semibold text-slate-900"
            >
              Registrar mascota
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Agregá un nuevo paciente al historial de la clínica.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar ventana"
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Nombre *
              </label>
              <input
                type="text"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                placeholder="Ej. Mora"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Propietario *
              </label>
              {lockOwner ? (
                <input
                  type="text"
                  readOnly
                  value={
                    propietarios.find((p) => p.id === propietarioId)?.nombre ??
                    'Tu cuenta'
                  }
                  className="w-full px-3 py-2 text-sm bg-slate-50 border border-slate-200 rounded-lg text-slate-700"
                />
              ) : (
                <select
                  value={propietarioId}
                  onChange={(e) => setPropietarioId(e.target.value)}
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                >
                  {propietarios.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.nombre}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Especie
              </label>
              <select
                value={especie}
                onChange={(e) => setEspecie(e.target.value as Especie)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
              >
                {ESPECIES.map((e) => (
                  <option key={e} value={e}>
                    {e}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Raza
              </label>
              <input
                type="text"
                value={raza}
                onChange={(e) => setRaza(e.target.value)}
                placeholder="Ej. Caniche Toy"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Edad
              </label>
              <input
                type="text"
                value={edad}
                onChange={(e) => setEdad(e.target.value)}
                placeholder="Ej. 3 años"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Peso (kg)
                </label>
                <input
                  type="text"
                  value={pesoKg}
                  onChange={(e) => setPesoKg(e.target.value)}
                  placeholder="6.4"
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg font-mono tabular-nums focus:outline-none focus:border-teal-600"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Sexo
                </label>
                <select
                  value={sexo}
                  onChange={(e) => setSexo(e.target.value as SexoMascota)}
                  className="w-full px-2.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
                >
                  <option value="Hembra">Hembra</option>
                  <option value="Macho">Macho</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Pelaje / Color
              </label>
              <input
                type="text"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                placeholder="Ej. Blanco y marrón"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Alergias o alertas
              </label>
              <input
                type="text"
                value={alergias}
                onChange={(e) => setAlergias(e.target.value)}
                placeholder="Ninguna conocida"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-teal-600"
              />
            </div>
          </div>

          {error && (
            <p
              role="alert"
              className="text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2"
            >
              {error}
            </p>
          )}

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800"
            >
              Guardar mascota
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
