import { useState } from 'react';
import { Bird, Cat, Dog, PawPrint, Rabbit } from 'lucide-react';
import { Especie } from '../types/veterinaria';

interface PetAvatarProps {
  nombre: string;
  especie: Especie;
  fotoUrl?: string;
  size?: 'sm' | 'md' | 'lg';
}

const SIZE_CLASSES: Record<NonNullable<PetAvatarProps['size']>, string> = {
  sm: 'w-9 h-9 rounded-lg',
  md: 'w-12 h-12 rounded-xl',
  lg: 'w-20 h-20 rounded-xl',
};

const ICON_SIZES: Record<NonNullable<PetAvatarProps['size']>, number> = {
  sm: 16,
  md: 20,
  lg: 28,
};

function SpeciesIcon({ especie, size }: { especie: Especie; size: number }) {
  switch (especie) {
    case 'Perro':
      return <Dog size={size} strokeWidth={1.75} />;
    case 'Gato':
      return <Cat size={size} strokeWidth={1.75} />;
    case 'Conejo':
      return <Rabbit size={size} strokeWidth={1.75} />;
    case 'Ave':
      return <Bird size={size} strokeWidth={1.75} />;
    default:
      return <PawPrint size={size} strokeWidth={1.75} />;
  }
}

export function PetAvatar({
  nombre,
  especie,
  fotoUrl,
  size = 'md',
}: PetAvatarProps) {
  const [failed, setFailed] = useState(false);

  if (fotoUrl && !failed) {
    return (
      <div
        className={`${SIZE_CLASSES[size]} shrink-0 overflow-hidden bg-slate-100 border border-slate-200`}
      >
        <img
          src={fotoUrl}
          alt={`Retrato de ${nombre}, ${especie.toLowerCase()}`}
          referrerPolicy="no-referrer"
          onError={() => setFailed(true)}
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  return (
    <div
      className={`${SIZE_CLASSES[size]} shrink-0 flex items-center justify-center bg-slate-100 border border-slate-200 text-slate-600`}
      aria-label={`${nombre}, ${especie}`}
    >
      <SpeciesIcon especie={especie} size={ICON_SIZES[size]} />
    </div>
  );
}
