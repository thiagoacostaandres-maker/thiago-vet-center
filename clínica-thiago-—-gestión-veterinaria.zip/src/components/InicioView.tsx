import { useState } from 'react';
import { ArrowRight, CalendarPlus, Stethoscope } from 'lucide-react';
import { ActiveSection, TipoConsulta } from '../types/veterinaria';
import { CLINIC_IMAGES } from '../data/seedData';

interface InicioViewProps {
  onNavigate: (section: ActiveSection) => void;
  onBookAppointment: (tipo?: TipoConsulta) => void;
  totalMascotas: number;
  turnosHoy: number;
}

export function InicioView({
  onNavigate,
  onBookAppointment,
  totalMascotas,
  turnosHoy,
}: InicioViewProps) {
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  return (
    <div className="space-y-12">
      {/* Hero 2 columnas equilibradas con altura completa */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-stretch">
        <div className="lg:col-span-6 flex flex-col justify-center py-2 space-y-6">
          <div className="space-y-4">
            <p className="text-xs font-medium text-teal-700 tracking-wide">
              Medicina veterinaria preventiva y clínica integral
            </p>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-slate-900 leading-[1.12] [text-wrap:balance]">
              Cuidado médico cercano para perros y gatos en Clínica Thiago
            </h1>
            <p className="text-base text-slate-600 leading-relaxed max-w-xl">
              Atención clínica general, vacunación al día, quirófano equipado y
              peluquería higiénica en un mismo lugar. Reservá tu turno en línea
              y seguí el estado de cada consulta.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              type="button"
              onClick={() => onBookAppointment()}
              className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
            >
              <CalendarPlus size={16} />
              <span>Reservar cita</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('servicios')}
              className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap shrink-0"
            >
              <span>Ver servicios</span>
              <ArrowRight size={15} />
            </button>
          </div>
        </div>

        <div className="lg:col-span-6">
          <div className="h-72 sm:h-88 lg:h-full min-h-[340px] rounded-xl overflow-hidden border border-slate-200 bg-slate-100">
            {!heroImgFailed ? (
              <img
                src={CLINIC_IMAGES.hero}
                alt="Veterinaria examinando a un perro junto a su tutora en Clínica Thiago"
                referrerPolicy="no-referrer"
                onError={() => setHeroImgFailed(true)}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center text-slate-500 bg-slate-100">
                <Stethoscope size={36} className="mb-3 text-teal-700" />
                <p className="text-sm font-medium text-slate-700">
                  Consultorios de Clínica Thiago
                </p>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Tira informativa de 4 columnas debajo del hero */}
      <section className="grid grid-cols-2 lg:grid-cols-4 bg-white border border-slate-200 rounded-xl divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
        <div className="p-5">
          <p className="text-xs text-slate-500">Horario de atención</p>
          <p className="text-base font-semibold text-slate-900 font-mono tabular-nums mt-1">
            09:00 – 19:30 hs
          </p>
          <p className="text-xs text-slate-500 mt-0.5">Lunes a sábados</p>
        </div>
        <div className="p-5">
          <p className="text-xs text-slate-500">Consultas hoy</p>
          <p className="text-base font-semibold text-slate-900 font-mono tabular-nums mt-1">
            {turnosHoy} turnos activos
          </p>
          <p className="text-xs text-slate-500 mt-0.5">Seguimiento en línea</p>
        </div>
        <div className="p-5">
          <p className="text-xs text-slate-500">Pacientes registrados</p>
          <p className="text-base font-semibold text-slate-900 font-mono tabular-nums mt-1">
            {totalMascotas} historias clínicas
          </p>
          <p className="text-xs text-slate-500 mt-0.5">Perros, gatos y más</p>
        </div>
        <div className="p-5">
          <p className="text-xs text-slate-500">Ubicación central</p>
          <p className="text-base font-semibold text-slate-900 mt-1 truncate">
            Av. Santa Fe 3420
          </p>
          <p className="text-xs text-slate-500 mt-0.5">Palermo, Buenos Aires</p>
        </div>
      </section>

      {/* Resumen de áreas principales */}
      <section className="space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2 border-b border-slate-200 pb-4">
          <div>
            <h2 className="text-xl font-semibold text-slate-900">
              Áreas de atención
            </h2>
            <p className="text-sm text-slate-500 mt-0.5">
              Acceso directo a nuestros servicios médicos, fichas de mascotas y reservas.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onNavigate('nosotros')}
            className="text-xs font-medium text-teal-700 hover:text-teal-800 hover:underline underline-offset-4 self-start sm:self-auto"
          >
            Conocer sobre la clínica
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between gap-5">
            <div className="space-y-2">
              <p className="text-xs font-mono text-slate-400">01</p>
              <h3 className="text-base font-semibold text-slate-900">
                Vacunación y consultas
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Esquemas completos de vacunación, desparasitación, diagnóstico
                clínico y controles periódicos para cada etapa de vida.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('servicios')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-700 hover:text-teal-900 w-fit"
            >
              <span>Explorar servicios</span>
              <ArrowRight size={14} />
            </button>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between gap-5">
            <div className="space-y-2">
              <p className="text-xs font-mono text-slate-400">02</p>
              <h3 className="text-base font-semibold text-slate-900">
                Guía de perros y gatos
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Recomendaciones de cuidado, calendario preventivo y acceso al
                directorio clínico de pacientes registrados.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('mascotas')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-700 hover:text-teal-900 w-fit"
            >
              <span>Ir a mascotas</span>
              <ArrowRight size={14} />
            </button>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between gap-5">
            <div className="space-y-2">
              <p className="text-xs font-mono text-slate-400">03</p>
              <h3 className="text-base font-semibold text-slate-900">
                Turnos y portal de usuarios
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Reservá citas médicas o de peluquería, actualizá el estado del
                turno e ingresá con tu cuenta de usuario.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('turnos')}
              className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-700 hover:text-teal-900 w-fit"
            >
              <span>Gestionar turnos</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
