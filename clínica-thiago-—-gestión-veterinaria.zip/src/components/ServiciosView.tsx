import { useState } from 'react';
import { CalendarPlus, Scissors } from 'lucide-react';
import { TipoConsulta } from '../types/veterinaria';
import { CLINIC_IMAGES } from '../data/seedData';

interface ServiciosViewProps {
  onBookService: (tipo: TipoConsulta) => void;
}

interface ServicioItem {
  numero: string;
  titulo: string;
  tipoTurno: TipoConsulta;
  duracion: string;
  descripcion: string;
  incluye: string[];
}

const SERVICIOS: ServicioItem[] = [
  {
    numero: '01',
    titulo: 'Vacunación y prevención',
    tipoTurno: 'Vacunación',
    duracion: '20 min',
    descripcion:
      'Plan de inmunización adaptado a la edad, especie y estilo de vida de cada mascota, con control clínico previo antes de aplicar cada dosis.',
    incluye: [
      'Séxtuple, antirrábica y tos de las perreras en perros',
      'Triple felina, leucemia y antirrábica en gatos',
      'Desparasitación interna y externa programada',
    ],
  },
  {
    numero: '02',
    titulo: 'Consultas clínicas generales',
    tipoTurno: 'Consulta general',
    duracion: '30 min',
    descripcion:
      'Evaluación integral ante síntomas agudos, controles de crecimiento en cachorros, seguimiento geriátrico, nutrición y dermatología.',
    incluye: [
      'Examen físico completo y registro de peso corporal',
      'Indicaciones terapéuticas y seguimiento por historia clínica',
      'Derivación a estudios de laboratorio o ecografía',
    ],
  },
  {
    numero: '03',
    titulo: 'Cirugías',
    tipoTurno: 'Cirugía',
    duracion: 'Turno programado',
    descripcion:
      'Quirófano equipado con monitoreo multiparamétrico y protocolos de anestesia segura para procedimientos programados y de tejidos blandos.',
    incluye: [
      'Esterilizaciones (castración) con evaluación prequirúrgica',
      'Extracción de nódulos, limpieza dental y suturas',
      'Control postoperatorio y manejo del dolor incluido',
    ],
  },
  {
    numero: '04',
    titulo: 'Peluquería y estética higiénica',
    tipoTurno: 'Peluquería',
    duracion: '60 min',
    descripcion:
      'Baños higiénicos y dermatológicos con productos hipoalergénicos, corte de raza o mantenimiento en un ambiente calmo y sin jaulas de espera prolongada.',
    incluye: [
      'Baño con agua templada y champú específico para su pelaje',
      'Corte higiénico, cepillado de subpelo y secado suave',
      'Limpieza de oídos y corte de uñas',
    ],
  },
];

export function ServiciosView({ onBookService }: ServiciosViewProps) {
  const [groomingImgFailed, setGroomingImgFailed] = useState(false);

  return (
    <div className="space-y-10">
      <div className="max-w-2xl space-y-2">
        <p className="text-xs font-medium text-teal-700">Prestaciones médicas</p>
        <h1 className="text-3xl font-bold tracking-tight text-slate-900">
          Servicios veterinarios
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed">
          Cubrimos medicina preventiva, atención clínica, cirugía programada y
          peluquería higiénica. Elegí el servicio que necesitás para reservar tu
          turno directamente.
        </p>
      </div>

      {/* Grilla de los 4 servicios solicitados */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {SERVICIOS.map((srv) => (
          <article
            key={srv.numero}
            className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between gap-6"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-mono font-medium text-teal-700">
                  {srv.numero}
                </span>
                <span className="font-mono tabular-nums">{srv.duracion}</span>
              </div>

              <h2 className="text-lg font-semibold text-slate-900">
                {srv.titulo}
              </h2>

              <p className="text-sm text-slate-600 leading-relaxed">
                {srv.descripcion}
              </p>

              <ul className="space-y-1.5 pt-2 border-t border-slate-100 text-xs text-slate-700">
                {srv.incluye.map((item) => (
                  <li key={item} className="flex items-start gap-2">
                    <span className="text-teal-700 font-bold" aria-hidden="true">
                      ·
                    </span>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={() => onBookService(srv.tipoTurno)}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-teal-800 bg-teal-50 border border-teal-200 rounded-lg hover:bg-teal-100 hover:border-teal-300 transition-colors whitespace-nowrap"
              >
                <CalendarPlus size={14} />
                <span>Reservar {srv.tipoTurno.toLowerCase()}</span>
              </button>
            </div>
          </article>
        ))}
      </div>

      {/* Destacado de Peluquería y Quirófano */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="lg:col-span-5 min-h-[240px] bg-slate-100">
          {!groomingImgFailed ? (
            <img
              src={CLINIC_IMAGES.grooming}
              alt="Sesión de peluquería canina en Clínica Thiago"
              referrerPolicy="no-referrer"
              onError={() => setGroomingImgFailed(true)}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center p-6 text-slate-500">
              <Scissors size={28} className="mb-2 text-teal-700" />
              <span className="text-xs">Peluquería veterinaria</span>
            </div>
          )}
        </div>
        <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-center space-y-4">
          <p className="text-xs font-medium text-teal-700">
            Atención integral bajo supervisión médica
          </p>
          <h2 className="text-xl font-semibold text-slate-900">
            Baños dermatológicos y preparación prequirúrgica segura
          </h2>
          <p className="text-sm text-slate-600 leading-relaxed">
            Al integrarse con nuestro equipo veterinario, el área de peluquería
            detecta tempranamente irritaciones de piel u otitis y aplica baños
            medicados indicados en consulta. Para cirugías, coordinamos el ayuno
            y análisis previos desde la agenda de turnos.
          </p>
          <div>
            <button
              type="button"
              onClick={() => onBookService('Peluquería')}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap"
            >
              <CalendarPlus size={15} />
              <span>Solicitar turno de servicio</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
