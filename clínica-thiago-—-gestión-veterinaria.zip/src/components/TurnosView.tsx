import { useMemo, useState } from 'react';
import { CalendarPlus, Lock, Search, ShieldCheck, UserCheck } from 'lucide-react';
import {
  EstadoTurno,
  Mascota,
  Propietario,
  Turno,
  Usuario,
} from '../types/veterinaria';
import { getTodayISO } from '../data/seedData';
import {
  ESTADOS_TURNO,
  formatFechaCorta,
  getNextEstado,
} from '../utils/formatters';
import { PetAvatar } from './PetAvatar';
import { StatusSelector, StatusText } from './StatusControl';

interface TurnosViewProps {
  currentUser: Usuario | null;
  turnos: Turno[];
  mascotas: Mascota[];
  propietarios: Propietario[];
  onChangeStatus: (turnoId: string, nuevoEstado: EstadoTurno) => void;
  onSelectTurno: (turnoId: string) => void;
  onOpenBookModal: () => void;
  onOpenAccess: (mode: 'clienta' | 'admin') => void;
}

type DateFilter = 'todos' | 'hoy' | 'proximos';

export function TurnosView({
  currentUser,
  turnos,
  mascotas,
  propietarios,
  onChangeStatus,
  onSelectTurno,
  onOpenBookModal,
  onOpenAccess,
}: TurnosViewProps) {
  const [statusFilter, setStatusFilter] = useState<'Todos' | EstadoTurno>(
    'Todos'
  );
  const [dateFilter, setDateFilter] = useState<DateFilter>('todos');
  const [search, setSearch] = useState('');

  const today = getTodayISO();

  const petMap = useMemo(
    () => new Map(mascotas.map((m) => [m.id, m])),
    [mascotas]
  );
  const ownerMap = useMemo(
    () => new Map(propietarios.map((p) => [p.id, p])),
    [propietarios]
  );

  const isAdmin = currentUser?.rol === 'Administrador';
  const isClienta = currentUser?.rol === 'Clienta';

  const scopedTurnos = useMemo(() => {
    if (isAdmin) return turnos;
    if (isClienta && currentUser?.propietarioId) {
      return turnos.filter(
        (t) => t.propietarioId === currentUser.propietarioId
      );
    }
    return [];
  }, [turnos, isAdmin, isClienta, currentUser]);

  const metrics = useMemo(() => {
    const todayTurns = scopedTurnos.filter(
      (t) => t.fecha === today && t.estado !== 'Cancelado'
    );
    const waiting = scopedTurnos.filter(
      (t) => t.estado === 'Pendiente' || t.estado === 'Confirmado'
    ).length;
    const inConsult = scopedTurnos.filter(
      (t) => t.estado === 'En consulta'
    ).length;
    const completed = scopedTurnos.filter(
      (t) => t.estado === 'Completado'
    ).length;
    return {
      hoy: todayTurns.length,
      espera: waiting,
      enConsulta: inConsult,
      completados: completed,
    };
  }, [scopedTurnos, today]);

  const filteredTurnos = useMemo(() => {
    const q = search.trim().toLowerCase();
    return [...scopedTurnos]
      .filter((t) => {
        if (statusFilter !== 'Todos' && t.estado !== statusFilter) return false;
        if (dateFilter === 'hoy' && t.fecha !== today) return false;
        if (dateFilter === 'proximos' && t.fecha < today) return false;

        if (!q) return true;
        const pet = petMap.get(t.mascotaId);
        const owner = ownerMap.get(t.propietarioId);
        return (
          t.codigo.toLowerCase().includes(q) ||
          t.motivo.toLowerCase().includes(q) ||
          t.veterinario.toLowerCase().includes(q) ||
          t.tipo.toLowerCase().includes(q) ||
          (pet?.nombre.toLowerCase().includes(q) ?? false) ||
          (owner?.nombre.toLowerCase().includes(q) ?? false)
        );
      })
      .sort((a, b) => {
        const dateCmp = a.fecha.localeCompare(b.fecha);
        if (dateCmp !== 0) return dateCmp;
        return a.hora.localeCompare(b.hora);
      });
  }, [
    scopedTurnos,
    statusFilter,
    dateFilter,
    search,
    today,
    petMap,
    ownerMap,
  ]);

  // Sin sesión activa: mostrar los 2 apartados de ingreso para Turnos
  if (!currentUser) {
    return (
      <div className="space-y-8">
        <div className="max-w-2xl space-y-1.5">
          <p className="text-xs font-medium text-teal-700">
            Reserva y gestión de consultas
          </p>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">
            Turnos de Clínica Thiago
          </h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Elegí cómo ingresar según tu rol: podés acceder como clienta para
            agendar tu turno o como administrador para gestionar la agenda de la
            clínica.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between gap-6">
            <div className="space-y-2.5">
              <div className="inline-flex items-center gap-2 text-xs font-medium text-teal-700">
                <UserCheck size={15} />
                <span>Apartado Clienta</span>
              </div>
              <h2 className="text-xl font-semibold text-slate-900">
                Quiero agendar una consulta
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Ingresá con tu correo o registrate como clienta para elegir
                horario, profesional, servicio y consultar tus turnos.
              </p>
            </div>
            <div>
              <button
                type="button"
                onClick={() => onOpenAccess('clienta')}
                className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap"
              >
                <CalendarPlus size={16} />
                <span>Ingresar como clienta</span>
              </button>
            </div>
          </section>

          <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col justify-between gap-6">
            <div className="space-y-2.5">
              <div className="inline-flex items-center gap-2 text-xs font-medium text-slate-600">
                <Lock size={15} />
                <span>Apartado Administrador</span>
              </div>
              <h2 className="text-xl font-semibold text-slate-900">
                Gestión clínica con contraseña
              </h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                Ingresá con la contraseña de administración para ver toda la
                agenda del día, cambiar el estado de las consultas y editar
                observaciones.
              </p>
            </div>
            <div>
              <button
                type="button"
                onClick={() => onOpenAccess('admin')}
                className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-slate-900 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors whitespace-nowrap"
              >
                <ShieldCheck size={16} />
                <span>Ingresar como administrador</span>
              </button>
            </div>
          </section>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Cabecera de sección */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-teal-700">
            {isAdmin
              ? 'Modo Administrador · Agenda completa'
              : `Portal Clienta · ${currentUser.nombre}`}
          </p>
          <h1 className="text-2xl font-semibold tracking-tight text-slate-900 mt-0.5">
            {isAdmin ? 'Agenda de turnos' : 'Mis turnos y reservas'}
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            {isAdmin
              ? 'Administrá todas las consultas programadas y actualizá su estado en tiempo real.'
              : 'Consultá el estado de tus citas médicas o reservá una nueva consulta para tus mascotas.'}
          </p>
        </div>

        <button
          type="button"
          onClick={onOpenBookModal}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <CalendarPlus size={16} />
          <span>Agendar consulta</span>
        </button>
      </div>

      {/* Tira de resumen */}
      <div className="grid grid-cols-2 lg:grid-cols-4 bg-white border border-slate-200 rounded-xl divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
        <div className="p-4 sm:px-5">
          <p className="text-xs font-medium text-slate-500">Turnos para hoy</p>
          <p className="text-2xl font-semibold text-slate-900 font-mono tabular-nums mt-1">
            {metrics.hoy}
          </p>
        </div>
        <div className="p-4 sm:px-5">
          <p className="text-xs font-medium text-slate-500">
            Pendientes y confirmados
          </p>
          <p className="text-2xl font-semibold text-slate-900 font-mono tabular-nums mt-1">
            {metrics.espera}
          </p>
        </div>
        <div className="p-4 sm:px-5">
          <p className="text-xs font-medium text-slate-500">En consulta ahora</p>
          <p className="text-2xl font-semibold text-teal-700 font-mono tabular-nums mt-1">
            {metrics.enConsulta}
          </p>
        </div>
        <div className="p-4 sm:px-5">
          <p className="text-xs font-medium text-slate-500">Completados</p>
          <p className="text-2xl font-semibold text-slate-900 font-mono tabular-nums mt-1">
            {metrics.completados}
          </p>
        </div>
      </div>

      {/* Barra de filtros y búsqueda */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg overflow-x-auto max-w-full">
            {(['Todos', ...ESTADOS_TURNO] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  statusFilter === st
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st}
              </button>
            ))}
          </div>

          <div className="inline-flex items-center p-1 bg-slate-100 rounded-lg">
            {(
              [
                { id: 'todos', label: 'Todas las fechas' },
                { id: 'hoy', label: 'Hoy' },
                { id: 'proximos', label: 'Próximos' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setDateFilter(opt.id)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  dateFilter === opt.id
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        <div className="relative w-full lg:w-72 shrink-0">
          <Search
            size={15}
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
          />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar mascota, código o motivo..."
            aria-label="Buscar turnos"
            className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-200 rounded-lg placeholder:text-slate-400 focus:outline-none focus:border-teal-600"
          />
        </div>
      </div>

      {/* Tabla de turnos */}
      {filteredTurnos.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-3">
          <p className="text-sm font-medium text-slate-900">
            No hay turnos que coincidan con los filtros actuales.
          </p>
          <p className="text-xs text-slate-500">
            Podés cambiar los criterios de búsqueda o agendar una nueva consulta.
          </p>
          <div className="flex items-center justify-center gap-3 pt-2">
            {(statusFilter !== 'Todos' ||
              dateFilter !== 'todos' ||
              search !== '') && (
              <button
                type="button"
                onClick={() => {
                  setStatusFilter('Todos');
                  setDateFilter('todos');
                  setSearch('');
                }}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 whitespace-nowrap"
              >
                Limpiar filtros
              </button>
            )}
            <button
              type="button"
              onClick={onOpenBookModal}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 whitespace-nowrap"
            >
              <CalendarPlus size={14} />
              <span>Agendar consulta</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-medium text-slate-500">
                  <th className="py-3 pl-5 pr-4 whitespace-nowrap">Fecha y hora</th>
                  <th className="py-3 px-4 whitespace-nowrap">Paciente</th>
                  {isAdmin && (
                    <th className="py-3 px-4 whitespace-nowrap">Propietario</th>
                  )}
                  <th className="py-3 px-4">Motivo y profesional</th>
                  <th className="py-3 px-4 whitespace-nowrap">Estado</th>
                  <th className="py-3 pl-4 pr-5 text-right whitespace-nowrap">
                    {isAdmin ? 'Acción rápida' : 'Acciones'}
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 text-sm">
                {filteredTurnos.map((turno) => {
                  const pet = petMap.get(turno.mascotaId);
                  const owner = ownerMap.get(turno.propietarioId);
                  const nextAction = getNextEstado(turno.estado);

                  return (
                    <tr
                      key={turno.id}
                      onClick={() => onSelectTurno(turno.id)}
                      className="hover:bg-slate-50/80 transition-colors cursor-pointer group"
                    >
                      <td className="py-3.5 pl-5 pr-4 align-middle whitespace-nowrap">
                        <div className="font-mono tabular-nums text-sm font-medium text-slate-900">
                          {turno.hora}
                        </div>
                        <div className="text-xs text-slate-500 font-mono tabular-nums">
                          {formatFechaCorta(turno.fecha)} · {turno.codigo}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 align-middle">
                        {pet ? (
                          <div className="flex items-center gap-3 min-w-[160px]">
                            <PetAvatar
                              nombre={pet.nombre}
                              especie={pet.especie}
                              fotoUrl={pet.fotoUrl}
                              size="sm"
                            />
                            <div className="min-w-0">
                              <div className="font-medium text-slate-900 truncate">
                                {pet.nombre}
                              </div>
                              <div className="text-xs text-slate-500 truncate">
                                {pet.especie} · {pet.raza}
                              </div>
                            </div>
                          </div>
                        ) : (
                          <span className="text-slate-400">Paciente no encontrado</span>
                        )}
                      </td>

                      {isAdmin && (
                        <td className="py-3.5 px-4 align-middle">
                          {owner ? (
                            <div className="min-w-[150px]">
                              <div className="font-medium text-slate-800 truncate">
                                {owner.nombre}
                              </div>
                              <div className="text-xs text-slate-500 font-mono tabular-nums">
                                {owner.telefono}
                              </div>
                            </div>
                          ) : (
                            <span className="text-slate-400">—</span>
                          )}
                        </td>
                      )}

                      <td className="py-3.5 px-4 align-middle max-w-xs">
                        <div className="font-medium text-slate-900 truncate">
                          {turno.motivo}
                        </div>
                        <div className="text-xs text-slate-500 truncate">
                          {turno.tipo}
                          <span className="mx-1.5" aria-hidden="true">·</span>
                          {turno.veterinario}
                        </div>
                      </td>

                      <td className="py-3.5 px-4 align-middle whitespace-nowrap">
                        {isAdmin ? (
                          <StatusSelector
                            estado={turno.estado}
                            onChange={(nuevoEstado) =>
                              onChangeStatus(turno.id, nuevoEstado)
                            }
                            ariaLabel={`Estado del turno de ${pet?.nombre ?? 'paciente'}`}
                          />
                        ) : (
                          <StatusText estado={turno.estado} />
                        )}
                      </td>

                      <td
                        className="py-3.5 pl-4 pr-5 align-middle text-right whitespace-nowrap"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {isAdmin ? (
                          nextAction ? (
                            <button
                              type="button"
                              onClick={() =>
                                onChangeStatus(turno.id, nextAction.next)
                              }
                              className="px-3 py-1.5 text-xs font-medium text-teal-800 bg-teal-50 border border-teal-200 rounded-md hover:bg-teal-100 hover:border-teal-300 transition-colors whitespace-nowrap shrink-0"
                            >
                              {nextAction.label}
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() => onSelectTurno(turno.id)}
                              className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
                            >
                              Ver detalle
                            </button>
                          )
                        ) : turno.estado === 'Pendiente' ||
                          turno.estado === 'Confirmado' ? (
                          <button
                            type="button"
                            onClick={() =>
                              onChangeStatus(turno.id, 'Cancelado')
                            }
                            className="px-3 py-1.5 text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-md hover:text-rose-700 hover:border-rose-200 transition-colors whitespace-nowrap shrink-0"
                          >
                            Cancelar turno
                          </button>
                        ) : (
                          <button
                            type="button"
                            onClick={() => onSelectTurno(turno.id)}
                            className="px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0"
                          >
                            Ver detalle
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
