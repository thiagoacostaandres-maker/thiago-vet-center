import { useEffect, useState } from 'react';
import {
  ArrowRight,
  Calendar,
  Clock,
  Mail,
  MapPin,
  Phone,
  User,
  X,
} from 'lucide-react';
import {
  EstadoTurno,
  Mascota,
  Propietario,
  Turno,
} from '../types/veterinaria';
import {
  ESTADOS_TURNO,
  formatFechaCompleta,
  getNextEstado,
} from '../utils/formatters';
import { PetAvatar } from './PetAvatar';
import { StatusText } from './StatusControl';

interface AppointmentDetailDrawerProps {
  turno: Turno | null;
  mascota?: Mascota;
  propietario?: Propietario;
  isAdmin: boolean;
  onClose: () => void;
  onChangeStatus: (turnoId: string, nuevoEstado: EstadoTurno) => void;
  onUpdateNotes: (turnoId: string, observaciones: string) => void;
  onOpenPetProfile: (mascotaId: string) => void;
}

export function AppointmentDetailDrawer({
  turno,
  mascota,
  propietario,
  isAdmin,
  onClose,
  onChangeStatus,
  onUpdateNotes,
  onOpenPetProfile,
}: AppointmentDetailDrawerProps) {
  const [notes, setNotes] = useState('');
  const [savedNotice, setSavedNotice] = useState(false);

  useEffect(() => {
    setNotes(turno?.observaciones ?? '');
    setSavedNotice(false);
  }, [turno]);

  useEffect(() => {
    if (!turno) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [turno, onClose]);

  if (!turno) return null;

  const nextAction = getNextEstado(turno.estado);

  function handleSaveNotes() {
    if (!turno) return;
    onUpdateNotes(turno.id, notes.trim());
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2000);
  }

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-900/30 backdrop-blur-[1px]"
      role="dialog"
      aria-modal="true"
      aria-labelledby="drawer-turno-titulo"
      onClick={onClose}
    >
      <aside
        className="w-full max-w-lg h-full bg-white border-l border-slate-200 shadow-xl flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <span className="font-mono tabular-nums font-medium text-slate-700">
                {turno.codigo}
              </span>
              <span aria-hidden="true">·</span>
              <span>{turno.tipo}</span>
            </div>
            <h2
              id="drawer-turno-titulo"
              className="text-lg font-semibold text-slate-900 mt-0.5"
            >
              Detalle de consulta
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar detalle"
            className="p-2 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-100 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Estado actual y cambio de estado */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-500">
                Estado del turno
              </span>
              <StatusText estado={turno.estado} />
            </div>

            {isAdmin ? (
              <>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {ESTADOS_TURNO.map((estado) => {
                    const active = turno.estado === estado;
                    return (
                      <button
                        key={estado}
                        type="button"
                        onClick={() => onChangeStatus(turno.id, estado)}
                        className={`px-3 py-2 text-xs font-medium rounded-lg border text-left transition-colors whitespace-nowrap shrink-0 ${
                          active
                            ? 'border-teal-700 bg-teal-50 text-teal-900'
                            : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:border-slate-300'
                        }`}
                      >
                        {estado}
                      </button>
                    );
                  })}
                </div>

                {nextAction && (
                  <button
                    type="button"
                    onClick={() => onChangeStatus(turno.id, nextAction.next)}
                    className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors"
                  >
                    <span>{nextAction.label}</span>
                    <ArrowRight size={15} />
                  </button>
                )}
              </>
            ) : (
              (turno.estado === 'Pendiente' || turno.estado === 'Confirmado') && (
                <button
                  type="button"
                  onClick={() => onChangeStatus(turno.id, 'Cancelado')}
                  className="px-4 py-2 text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 rounded-lg hover:bg-rose-100 transition-colors"
                >
                  Cancelar este turno
                </button>
              )
            )}
          </section>

          <hr className="border-slate-200" />

          {/* Fecha, hora y profesional */}
          <section className="space-y-3">
            <h3 className="text-xs font-medium text-slate-500">
              Programación
            </h3>
            <div className="space-y-2 text-sm text-slate-800">
              <div className="flex items-center gap-2.5">
                <Calendar size={15} className="text-slate-400 shrink-0" />
                <span className="capitalize">
                  {formatFechaCompleta(turno.fecha)}
                </span>
              </div>
              <div className="flex items-center gap-2.5">
                <Clock size={15} className="text-slate-400 shrink-0" />
                <span className="font-mono tabular-nums">{turno.hora} hs</span>
                <span className="text-slate-300" aria-hidden="true">·</span>
                <span>{turno.veterinario}</span>
              </div>
            </div>
            <div className="pt-1">
              <p className="text-xs font-medium text-slate-500 mb-1">
                Motivo de consulta
              </p>
              <p className="text-sm text-slate-900 leading-relaxed">
                {turno.motivo}
              </p>
            </div>
          </section>

          <hr className="border-slate-200" />

          {/* Paciente */}
          {mascota && (
            <section className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-medium text-slate-500">
                  Paciente
                </h3>
                <button
                  type="button"
                  onClick={() => onOpenPetProfile(mascota.id)}
                  className="text-xs font-medium text-teal-700 hover:text-teal-800 hover:underline underline-offset-4"
                >
                  Ver ficha clínica
                </button>
              </div>
              <div className="flex items-center gap-3.5">
                <PetAvatar
                  nombre={mascota.nombre}
                  especie={mascota.especie}
                  fotoUrl={mascota.fotoUrl}
                  size="md"
                />
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-slate-900">
                    {mascota.nombre}
                  </p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {mascota.especie}
                    <span className="mx-1.5" aria-hidden="true">·</span>
                    {mascota.raza}
                    <span className="mx-1.5" aria-hidden="true">·</span>
                    {mascota.edad}
                    <span className="mx-1.5" aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">
                      {mascota.pesoKg} kg
                    </span>
                  </p>
                </div>
              </div>
              {mascota.alergias && mascota.alergias !== 'Ninguna conocida' && (
                <p className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                  Alergias registradas: {mascota.alergias}
                </p>
              )}
            </section>
          )}

          <hr className="border-slate-200" />

          {/* Propietario */}
          {propietario && (
            <section className="space-y-2.5">
              <h3 className="text-xs font-medium text-slate-500">
                Propietario
              </h3>
              <div className="space-y-2 text-sm text-slate-700">
                <div className="flex items-center gap-2.5 text-slate-900 font-medium">
                  <User size={15} className="text-slate-400 shrink-0" />
                  <span>{propietario.nombre}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Phone size={15} className="text-slate-400 shrink-0" />
                  <span className="font-mono tabular-nums text-xs">
                    {propietario.telefono}
                  </span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Mail size={15} className="text-slate-400 shrink-0" />
                  <span className="text-xs">{propietario.email}</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <MapPin size={15} className="text-slate-400 shrink-0" />
                  <span className="text-xs">{propietario.direccion}</span>
                </div>
              </div>
            </section>
          )}

          <hr className="border-slate-200" />

          {/* Observaciones clínicas */}
          <section className="space-y-2.5">
            <div className="flex items-center justify-between">
              <label
                htmlFor="drawer-obs"
                className="text-xs font-medium text-slate-500"
              >
                Notas y observaciones de consulta
              </label>
              {savedNotice && (
                <span className="text-xs font-medium text-emerald-700">
                  Guardado
                </span>
              )}
            </div>
            {isAdmin ? (
              <>
                <textarea
                  id="drawer-obs"
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Anotaciones clínicas, indicaciones o tratamiento..."
                  className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg resize-none focus:outline-none focus:border-teal-600"
                />
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={handleSaveNotes}
                    className="px-3.5 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    Guardar notas
                  </button>
                </div>
              </>
            ) : (
              <p className="text-sm text-slate-700 leading-relaxed">
                {turno.observaciones || 'Sin observaciones registradas por el profesional.'}
              </p>
            )}
          </section>
        </div>
      </aside>
    </div>
  );
}
