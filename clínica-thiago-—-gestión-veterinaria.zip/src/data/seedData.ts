import goldenRetrieverImg from '../assets/images/pet_golden_retriever_1794699745304.jpg';
import tabbyCatImg from '../assets/images/pet_tabby_cat_1794699745501.jpg';
import frenchBulldogImg from '../assets/images/pet_french_bulldog_1794699744804.jpg';
import lopRabbitImg from '../assets/images/pet_lop_rabbit_1794699745685.jpg';
import heroClinicImg from '../assets/images/hero_veterinary_clinic_1794702040985.jpg';
import aboutClinicImg from '../assets/images/about_clinic_team_1794702041745.jpg';
import groomingServiceImg from '../assets/images/service_pet_grooming_1794702041510.jpg';
import { Mascota, Propietario, Turno, Usuario } from '../types/veterinaria';

export const CLINIC_IMAGES = {
  hero: heroClinicImg,
  about: aboutClinicImg,
  grooming: groomingServiceImg,
  dogPortrait: goldenRetrieverImg,
  catPortrait: tabbyCatImg,
};

export function getTodayISO(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function addDaysISO(baseIso: string, days: number): string {
  const [y, m, d] = baseIso.split('-').map(Number);
  const dt = new Date(y, m - 1, d);
  dt.setDate(dt.getDate() + days);
  const ry = dt.getFullYear();
  const rm = String(dt.getMonth() + 1).padStart(2, '0');
  const rd = String(dt.getDate()).padStart(2, '0');
  return `${ry}-${rm}-${rd}`;
}

const hoy = getTodayISO();
const manana = addDaysISO(hoy, 1);
const pasadoManana = addDaysISO(hoy, 2);
const ayer = addDaysISO(hoy, -1);

export const VETERINARIOS = [
  'Dra. Valeria Méndez',
  'Dr. Martín Sosa',
  'Dra. Lucía Ferreyra',
];

export const HORARIOS_DISPONIBLES = [
  '09:00',
  '09:30',
  '10:00',
  '10:30',
  '11:00',
  '11:30',
  '12:00',
  '14:00',
  '14:30',
  '15:00',
  '15:30',
  '16:00',
  '16:30',
  '17:00',
  '17:30',
  '18:00',
  '18:30',
  '19:00',
];

export const SEED_PROPIETARIOS: Propietario[] = [
  {
    id: 'prop-1',
    nombre: 'Camila Rodríguez',
    telefono: '+54 11 4829-3104',
    email: 'camila.rodriguez@correo.com',
    direccion: 'Av. del Libertador 2410, Piso 4',
    dni: '34.892.115',
    notas: 'Prefiere confirmación por WhatsApp antes de las 10:00.',
  },
  {
    id: 'prop-2',
    nombre: 'Tomás Echeverría',
    telefono: '+54 11 5930-7741',
    email: 'tomas.echeverria@correo.com',
    direccion: 'Pasaje Malabia 1842',
    dni: '29.410.682',
  },
  {
    id: 'prop-3',
    nombre: 'Sofía Benítez',
    telefono: '+54 11 6102-8835',
    email: 'sofia.benitez@correo.com',
    direccion: 'Calle Gurruchaga 915, Depto B',
    dni: '38.104.520',
    notas: 'Solicita historia clínica impresa tras cada control.',
  },
  {
    id: 'prop-4',
    nombre: 'Alejandro Morales',
    telefono: '+54 11 4512-0943',
    email: 'a.morales@correo.com',
    direccion: 'Av. Cabildo 3190',
    dni: '26.774.309',
  },
  {
    id: 'prop-5',
    nombre: 'Paula Villalba',
    telefono: '+54 11 3849-1260',
    email: 'paula.villalba@correo.com',
    direccion: 'Arce 540, PB',
    dni: '36.501.844',
  },
];

export const SEED_MASCOTAS: Mascota[] = [
  {
    id: 'masc-1',
    nombre: 'Milo',
    especie: 'Perro',
    raza: 'Golden Retriever',
    edad: '4 años',
    pesoKg: 29.4,
    sexo: 'Macho',
    color: 'Dorado',
    propietarioId: 'prop-1',
    alergias: 'Polen estacional',
    fotoUrl: goldenRetrieverImg,
  },
  {
    id: 'masc-2',
    nombre: 'Naranjo',
    especie: 'Gato',
    raza: 'Europeo Común',
    edad: '3 años',
    pesoKg: 4.6,
    sexo: 'Macho',
    color: 'Atigrado naranja y blanco',
    propietarioId: 'prop-2',
    alergias: 'Ninguna conocida',
    fotoUrl: tabbyCatImg,
  },
  {
    id: 'masc-3',
    nombre: 'Oli',
    especie: 'Perro',
    raza: 'Bulldog Francés',
    edad: '2 años',
    pesoKg: 11.2,
    sexo: 'Hembra',
    color: 'Leonado',
    propietarioId: 'prop-3',
    alergias: 'Proteína de pollo',
    fotoUrl: frenchBulldogImg,
  },
  {
    id: 'masc-4',
    nombre: 'Copo',
    especie: 'Conejo',
    raza: 'Holland Lop',
    edad: '1 año',
    pesoKg: 1.8,
    sexo: 'Macho',
    color: 'Crema y blanco',
    propietarioId: 'prop-4',
    alergias: 'Ninguna conocida',
    fotoUrl: lopRabbitImg,
  },
  {
    id: 'masc-5',
    nombre: 'Luna',
    especie: 'Gato',
    raza: 'Siamés',
    edad: '6 años',
    pesoKg: 3.9,
    sexo: 'Hembra',
    color: 'Cream point',
    propietarioId: 'prop-1',
    alergias: 'Ninguna conocida',
  },
  {
    id: 'masc-6',
    nombre: 'Simón',
    especie: 'Perro',
    raza: 'Mestizo',
    edad: '7 años',
    pesoKg: 18.5,
    sexo: 'Macho',
    color: 'Negro y fuego',
    propietarioId: 'prop-5',
    alergias: 'Picadura de pulga',
  },
];

export const SEED_TURNOS: Turno[] = [
  {
    id: 'turn-1',
    codigo: 'TUR-1042',
    mascotaId: 'masc-1',
    propietarioId: 'prop-1',
    fecha: hoy,
    hora: '09:30',
    tipo: 'Control clínico',
    motivo: 'Control dermatológico por alergia estacional',
    veterinario: 'Dra. Valeria Méndez',
    estado: 'En consulta',
    observaciones: 'Revisar respuesta a antihistamínico oral y estado del pelaje.',
  },
  {
    id: 'turn-2',
    codigo: 'TUR-1043',
    mascotaId: 'masc-3',
    propietarioId: 'prop-3',
    fecha: hoy,
    hora: '10:30',
    tipo: 'Vacunación',
    motivo: 'Refuerzo anual séxtuple y antirrábica',
    veterinario: 'Dr. Martín Sosa',
    estado: 'Confirmado',
    observaciones: 'Trae libreta sanitaria física.',
  },
  {
    id: 'turn-3',
    codigo: 'TUR-1044',
    mascotaId: 'masc-2',
    propietarioId: 'prop-2',
    fecha: hoy,
    hora: '11:30',
    tipo: 'Consulta general',
    motivo: 'Disminución del apetito últimos dos días',
    veterinario: 'Dra. Lucía Ferreyra',
    estado: 'Pendiente',
    observaciones: 'Evaluar hidratación y palpación abdominal.',
  },
  {
    id: 'turn-4',
    codigo: 'TUR-1045',
    mascotaId: 'masc-4',
    propietarioId: 'prop-4',
    fecha: hoy,
    hora: '15:00',
    tipo: 'Control clínico',
    motivo: 'Revisión dental y recorte de uñas',
    veterinario: 'Dra. Valeria Méndez',
    estado: 'Pendiente',
  },
  {
    id: 'turn-5',
    codigo: 'TUR-1046',
    mascotaId: 'masc-6',
    propietarioId: 'prop-5',
    fecha: hoy,
    hora: '16:30',
    tipo: 'Desparasitación',
    motivo: 'Desparasitación interna y externa trimestral',
    veterinario: 'Dr. Martín Sosa',
    estado: 'Confirmado',
  },
  {
    id: 'turn-6',
    codigo: 'TUR-1040',
    mascotaId: 'masc-5',
    propietarioId: 'prop-1',
    fecha: ayer,
    hora: '17:00',
    tipo: 'Consulta general',
    motivo: 'Limpieza dental preventiva',
    veterinario: 'Dra. Lucía Ferreyra',
    estado: 'Completado',
    observaciones: 'Procedimiento sin complicaciones. Control en 30 días.',
  },
  {
    id: 'turn-7',
    codigo: 'TUR-1041',
    mascotaId: 'masc-2',
    propietarioId: 'prop-2',
    fecha: ayer,
    hora: '18:00',
    tipo: 'Vacunación',
    motivo: 'Triple felina',
    veterinario: 'Dr. Martín Sosa',
    estado: 'Cancelado',
    observaciones: 'Reprogramado por el propietario.',
  },
  {
    id: 'turn-8',
    codigo: 'TUR-1047',
    mascotaId: 'masc-5',
    propietarioId: 'prop-1',
    fecha: manana,
    hora: '10:00',
    tipo: 'Control clínico',
    motivo: 'Seguimiento post-limpieza dental',
    veterinario: 'Dra. Lucía Ferreyra',
    estado: 'Confirmado',
  },
  {
    id: 'turn-9',
    codigo: 'TUR-1048',
    mascotaId: 'masc-1',
    propietarioId: 'prop-1',
    fecha: pasadoManana,
    hora: '14:30',
    tipo: 'Vacunación',
    motivo: 'Refuerzo tos de las perreras',
    veterinario: 'Dra. Valeria Méndez',
    estado: 'Pendiente',
  },
];

export const ADMIN_PASSWORD = 'Thiago 123';

export const SEED_USUARIOS: Usuario[] = [
  {
    id: 'usr-1',
    nombre: 'Camila Rodríguez',
    email: 'camila.rodriguez@correo.com',
    telefono: '+54 11 4829-3104',
    rol: 'Clienta',
    propietarioId: 'prop-1',
  },
  {
    id: 'usr-admin',
    nombre: 'Administrador Clínica Thiago',
    email: 'admin@clinicathiago.com',
    telefono: '+54 11 4800-2210',
    rol: 'Administrador',
  },
];
