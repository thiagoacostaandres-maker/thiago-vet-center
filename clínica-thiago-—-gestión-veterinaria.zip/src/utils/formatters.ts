import { EstadoTurno } from '../types/veterinaria';
import { getTodayISO, addDaysISO } from '../data/seedData';

export function formatFechaCorta(isoDate: string): string {
  const hoy = getTodayISO();
  const manana = addDaysISO(hoy, 1);
  const ayer = addDaysISO(hoy, -1);

  if (isoDate === hoy) return 'Hoy';
  if (isoDate === manana) return 'Mañana';
  if (isoDate === ayer) return 'Ayer';

  const [y, m, d] = isoDate.split('-').map(Number);
  if (!y || !m || !d) return isoDate;
  const date = new Date(y, m - 1, d);
  return date.toLocaleDateString('es-AR', {
    day: '2-digit',
    month: 'short',
  });
}

export function formatFechaCompleta(isoDate: string): string {
  const [y, m, d] = isoDate.split('-').map(Number);
  if (!y || !m || !d) return isoDate;
  const date = new Date(y, m - 1, d);
  return date.toLocaleDateString('es-AR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });
}

export const ESTADOS_TURNO: EstadoTurno[] = [
  'Pendiente',
  'Confirmado',
  'En consulta',
  'Completado',
  'Cancelado',
];

export function getNextEstado(estado: EstadoTurno): {
  next: EstadoTurno;
  label: string;
} | null {
  switch (estado) {
    case 'Pendiente':
      return { next: 'Confirmado', label: 'Confirmar' };
    case 'Confirmado':
      return { next: 'En consulta', label: 'Iniciar consulta' };
    case 'En consulta':
      return { next: 'Completado', label: 'Finalizar' };
    default:
      return null;
  }
}
