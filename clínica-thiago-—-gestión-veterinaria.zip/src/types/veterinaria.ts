export type Especie = 'Perro' | 'Gato' | 'Conejo' | 'Ave' | 'Otro';

export type SexoMascota = 'Macho' | 'Hembra';

export type EstadoTurno =
  | 'Pendiente'
  | 'Confirmado'
  | 'En consulta'
  | 'Completado'
  | 'Cancelado';

export type TipoConsulta =
  | 'Consulta general'
  | 'Vacunación'
  | 'Control clínico'
  | 'Cirugía'
  | 'Peluquería'
  | 'Urgencia'
  | 'Desparasitación';

export interface Propietario {
  id: string;
  nombre: string;
  telefono: string;
  email: string;
  direccion: string;
  dni: string;
  notas?: string;
}

export interface Mascota {
  id: string;
  nombre: string;
  especie: Especie;
  raza: string;
  edad: string;
  pesoKg: number;
  sexo: SexoMascota;
  color: string;
  propietarioId: string;
  alergias?: string;
  fotoUrl?: string;
}

export interface Turno {
  id: string;
  codigo: string;
  mascotaId: string;
  propietarioId: string;
  fecha: string; // YYYY-MM-DD
  hora: string;  // HH:MM
  tipo: TipoConsulta;
  motivo: string;
  veterinario: string;
  estado: EstadoTurno;
  observaciones?: string;
}

export interface Usuario {
  id: string;
  nombre: string;
  email: string;
  telefono: string;
  rol: 'Clienta' | 'Administrador';
  propietarioId?: string;
}

export type ActiveSection =
  | 'inicio'
  | 'nosotros'
  | 'servicios'
  | 'mascotas'
  | 'turnos'
  | 'usuarios'
  | 'contacto';
