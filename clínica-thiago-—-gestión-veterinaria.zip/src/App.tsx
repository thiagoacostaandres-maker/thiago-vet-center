import { useEffect, useMemo, useState } from 'react';
import { CalendarPlus, Menu, RotateCcw, X } from 'lucide-react';
import {
  ActiveSection,
  EstadoTurno,
  Mascota,
  Propietario,
  TipoConsulta,
  Turno,
  Usuario,
} from './types/veterinaria';
import {
  ADMIN_PASSWORD,
  getTodayISO,
  SEED_MASCOTAS,
  SEED_PROPIETARIOS,
  SEED_TURNOS,
  SEED_USUARIOS,
} from './data/seedData';
import { InicioView } from './components/InicioView';
import { NosotrosView } from './components/NosotrosView';
import { ServiciosView } from './components/ServiciosView';
import { MascotasView } from './components/MascotasView';
import { TurnosView } from './components/TurnosView';
import { UsuariosView } from './components/UsuariosView';
import { ContactoView } from './components/ContactoView';
import { BookAppointmentModal } from './components/BookAppointmentModal';
import { AppointmentDetailDrawer } from './components/AppointmentDetailDrawer';
import { PetDetailDrawer } from './components/PetDetailDrawer';
import { NewPetModal } from './components/NewPetModal';
import { NewOwnerModal } from './components/NewOwnerModal';

const STORAGE_KEY = 'clinica_thiago_veterinaria_v3';

interface ClinicStore {
  propietarios: Propietario[];
  mascotas: Mascota[];
  turnos: Turno[];
  usuarios: Usuario[];
  currentUserId: string | null;
}

function loadInitialStore(): ClinicStore {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<ClinicStore>;
      if (
        Array.isArray(parsed.propietarios) &&
        Array.isArray(parsed.mascotas) &&
        Array.isArray(parsed.turnos)
      ) {
        return {
          propietarios: parsed.propietarios,
          mascotas: parsed.mascotas,
          turnos: parsed.turnos,
          usuarios: Array.isArray(parsed.usuarios)
            ? parsed.usuarios
            : SEED_USUARIOS,
          currentUserId: parsed.currentUserId ?? null,
        };
      }
    }
  } catch {
    // Usar datos iniciales si localStorage no está disponible
  }
  return {
    propietarios: SEED_PROPIETARIOS,
    mascotas: SEED_MASCOTAS,
    turnos: SEED_TURNOS,
    usuarios: SEED_USUARIOS,
    currentUserId: null,
  };
}

const NAV_ITEMS: { id: ActiveSection; label: string }[] = [
  { id: 'inicio', label: 'Inicio' },
  { id: 'nosotros', label: 'Nosotros' },
  { id: 'servicios', label: 'Servicios' },
  { id: 'mascotas', label: 'Mascotas' },
  { id: 'turnos', label: 'Turnos' },
  { id: 'usuarios', label: 'Usuarios' },
  { id: 'contacto', label: 'Contacto' },
];

export default function App() {
  const [store, setStore] = useState<ClinicStore>(loadInitialStore);
  const [activeSection, setActiveSection] = useState<ActiveSection>('inicio');
  const [preferredAccessPanel, setPreferredAccessPanel] = useState<
    'clienta' | 'admin'
  >('clienta');
  const [pendingBooking, setPendingBooking] = useState<{
    mascotaId?: string;
    tipo?: TipoConsulta;
  } | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Modales y paneles laterales
  const [bookModalOpen, setBookModalOpen] = useState(false);
  const [bookPreselectedPetId, setBookPreselectedPetId] = useState<
    string | undefined
  >(undefined);
  const [bookPreselectedTipo, setBookPreselectedTipo] = useState<
    TipoConsulta | undefined
  >(undefined);
  const [newPetModalOpen, setNewPetModalOpen] = useState(false);
  const [newPetOwnerId, setNewPetOwnerId] = useState<string | undefined>(
    undefined
  );
  const [newOwnerModalOpen, setNewOwnerModalOpen] = useState(false);

  const [selectedTurnoId, setSelectedTurnoId] = useState<string | null>(null);
  const [selectedPetId, setSelectedPetId] = useState<string | null>(null);

  const [confirmReset, setConfirmReset] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
    } catch {
      // Ignorar errores de cuota
    }
  }, [store]);

  useEffect(() => {
    if (!feedback) return;
    const timer = setTimeout(() => setFeedback(null), 3200);
    return () => clearTimeout(timer);
  }, [feedback]);

  const ownerMap = useMemo(
    () => new Map(store.propietarios.map((p) => [p.id, p])),
    [store.propietarios]
  );
  const petMap = useMemo(
    () => new Map(store.mascotas.map((m) => [m.id, m])),
    [store.mascotas]
  );

  const currentUser = useMemo(
    () => store.usuarios.find((u) => u.id === store.currentUserId) ?? null,
    [store.usuarios, store.currentUserId]
  );

  const isAdmin = currentUser?.rol === 'Administrador';

  const selectedTurno = useMemo(
    () => store.turnos.find((t) => t.id === selectedTurnoId) ?? null,
    [store.turnos, selectedTurnoId]
  );
  const selectedPet = useMemo(
    () => store.mascotas.find((m) => m.id === selectedPetId) ?? null,
    [store.mascotas, selectedPetId]
  );

  const today = getTodayISO();
  const turnosHoyCount = useMemo(
    () =>
      store.turnos.filter(
        (t) => t.fecha === today && t.estado !== 'Cancelado'
      ).length,
    [store.turnos, today]
  );

  function showToast(msg: string) {
    setFeedback(msg);
  }

  function navigateTo(section: ActiveSection) {
    setActiveSection(section);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function openAccessPanel(mode: 'clienta' | 'admin') {
    setPreferredAccessPanel(mode);
    setPendingBooking(null);
    navigateTo('usuarios');
  }

  function handleOpenBookModal(mascotaId?: string, tipo?: TipoConsulta) {
    if (!currentUser) {
      setPreferredAccessPanel('clienta');
      setPendingBooking({ mascotaId, tipo });
      navigateTo('usuarios');
      return;
    }
    setBookPreselectedPetId(mascotaId);
    setBookPreselectedTipo(tipo);
    setBookModalOpen(true);
  }

  function handleCreateAppointment(payload: {
    turno: Omit<Turno, 'id' | 'codigo'>;
    newOwner?: Omit<Propietario, 'id'>;
    newPet?: Omit<Mascota, 'id' | 'propietarioId'>;
  }) {
    const nowId = Date.now().toString(36);
    let ownerId = payload.turno.propietarioId;
    let petId = payload.turno.mascotaId;

    const nextOwners = [...store.propietarios];
    const nextPets = [...store.mascotas];

    if (currentUser?.rol === 'Clienta' && currentUser.propietarioId) {
      ownerId = currentUser.propietarioId;
    } else if (payload.newOwner) {
      ownerId = `prop-${nowId}`;
      nextOwners.unshift({ ...payload.newOwner, id: ownerId });
    }

    if (payload.newPet) {
      petId = `masc-${nowId}`;
      nextPets.unshift({
        ...payload.newPet,
        id: petId,
        propietarioId: ownerId,
      });
    }

    const nextCodeNum = 1040 + store.turnos.length + 1;
    const newTurno: Turno = {
      ...payload.turno,
      id: `turn-${nowId}`,
      codigo: `TUR-${nextCodeNum}`,
      mascotaId: petId,
      propietarioId: ownerId,
      estado:
        currentUser?.rol === 'Clienta' ? 'Pendiente' : payload.turno.estado,
    };

    setStore((prev) => ({
      ...prev,
      propietarios: nextOwners,
      mascotas: nextPets,
      turnos: [newTurno, ...prev.turnos],
    }));

    const petName =
      nextPets.find((m) => m.id === petId)?.nombre ?? 'la mascota';
    showToast(`Turno ${newTurno.codigo} reservado para ${petName}.`);
    navigateTo('turnos');
  }

  function handleChangeTurnoStatus(turnoId: string, nuevoEstado: EstadoTurno) {
    const target = store.turnos.find((t) => t.id === turnoId);
    if (!target || target.estado === nuevoEstado) return;

    if (!isAdmin && nuevoEstado !== 'Cancelado') {
      return;
    }

    setStore((prev) => ({
      ...prev,
      turnos: prev.turnos.map((t) =>
        t.id === turnoId ? { ...t, estado: nuevoEstado } : t
      ),
    }));

    const petName = petMap.get(target.mascotaId)?.nombre ?? 'el paciente';
    showToast(`Turno de ${petName} actualizado a "${nuevoEstado}".`);
  }

  function handleUpdateTurnoNotes(turnoId: string, observaciones: string) {
    if (!isAdmin) return;
    setStore((prev) => ({
      ...prev,
      turnos: prev.turnos.map((t) =>
        t.id === turnoId
          ? { ...t, observaciones: observaciones || undefined }
          : t
      ),
    }));
  }

  function handleCreatePet(petData: Omit<Mascota, 'id'>) {
    const resolvedOwnerId =
      currentUser?.rol === 'Clienta' && currentUser.propietarioId
        ? currentUser.propietarioId
        : petData.propietarioId;

    const newPet: Mascota = {
      ...petData,
      propietarioId: resolvedOwnerId,
      id: `masc-${Date.now().toString(36)}`,
    };
    setStore((prev) => ({
      ...prev,
      mascotas: [newPet, ...prev.mascotas],
    }));
    showToast(`Mascota "${newPet.nombre}" registrada.`);
  }

  function handleCreateOwner(ownerData: Omit<Propietario, 'id'>) {
    const newOwner: Propietario = {
      ...ownerData,
      id: `prop-${Date.now().toString(36)}`,
    };
    setStore((prev) => ({
      ...prev,
      propietarios: [newOwner, ...prev.propietarios],
    }));
    showToast(`Propietario "${newOwner.nombre}" registrado.`);
  }

  function handleLoginClient(email: string): { ok: boolean; error?: string } {
    const found = store.usuarios.find(
      (u) =>
        u.rol === 'Clienta' && u.email.toLowerCase() === email.toLowerCase()
    );
    if (!found) {
      return {
        ok: false,
        error: 'No encontramos una cuenta de clienta con ese correo.',
      };
    }
    setStore((prev) => ({ ...prev, currentUserId: found.id }));
    showToast(`Bienvenida, ${found.nombre}.`);

    if (pendingBooking) {
      setBookPreselectedPetId(pendingBooking.mascotaId);
      setBookPreselectedTipo(pendingBooking.tipo);
      setPendingBooking(null);
      setBookModalOpen(true);
    }
    return { ok: true };
  }

  function handleRegisterClient(payload: {
    nombre: string;
    email: string;
    telefono: string;
  }): { ok: boolean; error?: string } {
    const exists = store.usuarios.some(
      (u) => u.email.toLowerCase() === payload.email.toLowerCase()
    );
    if (exists) {
      return { ok: false, error: 'Ya existe una cuenta con ese correo.' };
    }

    const nowId = Date.now().toString(36);
    const propietarioId = `prop-${nowId}`;
    const newOwner: Propietario = {
      id: propietarioId,
      nombre: payload.nombre,
      telefono: payload.telefono,
      email: payload.email,
      direccion: 'Sin domicilio cargado',
      dni: 'Sin DNI',
    };

    const newUser: Usuario = {
      id: `usr-${nowId}`,
      nombre: payload.nombre,
      email: payload.email,
      telefono: payload.telefono,
      rol: 'Clienta',
      propietarioId,
    };

    setStore((prev) => ({
      ...prev,
      propietarios: [newOwner, ...prev.propietarios],
      usuarios: [newUser, ...prev.usuarios],
      currentUserId: newUser.id,
    }));

    showToast(`Cuenta de clienta creada. ¡Bienvenida, ${newUser.nombre}!`);

    if (pendingBooking) {
      setBookPreselectedPetId(pendingBooking.mascotaId);
      setBookPreselectedTipo(pendingBooking.tipo);
      setPendingBooking(null);
      setBookModalOpen(true);
    }
    return { ok: true };
  }

  function handleLoginAdmin(password: string): { ok: boolean; error?: string } {
    if (password !== ADMIN_PASSWORD) {
      return { ok: false, error: 'Contraseña de administrador incorrecta.' };
    }
    const adminUser = store.usuarios.find((u) => u.rol === 'Administrador');
    if (adminUser) {
      setStore((prev) => ({ ...prev, currentUserId: adminUser.id }));
    }
    setPendingBooking(null);
    showToast('Sesión iniciada como Administrador.');
    navigateTo('turnos');
    return { ok: true };
  }

  function handleLogout() {
    setStore((prev) => ({ ...prev, currentUserId: null }));
    setSelectedTurnoId(null);
    setSelectedPetId(null);
    setPendingBooking(null);
    showToast('Sesión cerrada.');
  }

  function handleResetDemo() {
    setStore({
      propietarios: SEED_PROPIETARIOS,
      mascotas: SEED_MASCOTAS,
      turnos: SEED_TURNOS,
      usuarios: SEED_USUARIOS,
      currentUserId: null,
    });
    setSelectedTurnoId(null);
    setSelectedPetId(null);
    setPendingBooking(null);
    setConfirmReset(false);
    showToast('Datos iniciales restaurados.');
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      {/* Top Bar Contract: [Brand title] — [Nav links] — [1 Primary CTA] */}
      <header className="sticky top-0 z-30 bg-white border-b border-slate-200">
        <div className="max-w-[1280px] mx-auto h-16 px-4 sm:px-8 flex items-center justify-between gap-6">
          {/* Zone 1: Brand wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Abrir navegación"
              className="lg:hidden p-2 -ml-2 rounded-lg text-slate-600 hover:bg-slate-100"
            >
              <Menu size={19} />
            </button>
            <button
              type="button"
              onClick={() => navigateTo('inicio')}
              className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
            >
              Clínica Thiago
            </button>
          </div>

          {/* Zone 2: Enlaces de navegación de una sola línea */}
          <nav
            aria-label="Navegación principal"
            className="hidden lg:flex items-center gap-6 text-sm font-medium"
          >
            {NAV_ITEMS.map((item) => {
              const active = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => navigateTo(item.id)}
                  className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                    active
                      ? 'text-slate-900 border-teal-700'
                      : 'text-slate-600 border-transparent hover:text-slate-900 hover:border-slate-300'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: 1 acción principal */}
          <div className="shrink-0">
            <button
              type="button"
              onClick={() => handleOpenBookModal()}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium text-white bg-teal-700 rounded-lg hover:bg-teal-800 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-teal-700"
            >
              <CalendarPlus size={15} />
              <span>Reservar turno</span>
            </button>
          </div>
        </div>
      </header>

      {/* Menú móvil */}
      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-40 lg:hidden flex bg-slate-900/30"
          onClick={() => setMobileMenuOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-64 h-full bg-white border-r border-slate-200 flex flex-col"
          >
            <div className="h-16 px-5 flex items-center justify-between border-b border-slate-200">
              <span className="text-base font-bold text-slate-900">
                Clínica Thiago
              </span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Cerrar menú"
                className="p-1.5 rounded-md text-slate-500 hover:bg-slate-100"
              >
                <X size={18} />
              </button>
            </div>
            <nav aria-label="Navegación móvil" className="p-4 space-y-1 flex-1">
              {NAV_ITEMS.map((item) => {
                const active = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => navigateTo(item.id)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                      active
                        ? 'bg-teal-50 text-teal-900'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    }`}
                  >
                    {item.label}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
      )}

      {/* Aviso discreto */}
      {feedback && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 flex items-center gap-3 px-4 py-3 bg-slate-900 text-white text-xs sm:text-sm font-medium rounded-lg shadow-lg"
        >
          <span>{feedback}</span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            aria-label="Cerrar aviso"
            className="text-slate-300 hover:text-white"
          >
            <X size={15} />
          </button>
        </div>
      )}

      {/* Contenido principal */}
      <main className="flex-1 w-full max-w-[1280px] mx-auto px-4 sm:px-8 py-8 sm:py-10">
        {activeSection === 'inicio' && (
          <InicioView
            onNavigate={navigateTo}
            onBookAppointment={(tipo) => handleOpenBookModal(undefined, tipo)}
            totalMascotas={store.mascotas.length}
            turnosHoy={turnosHoyCount}
          />
        )}

        {activeSection === 'nosotros' && (
          <NosotrosView onBookAppointment={() => handleOpenBookModal()} />
        )}

        {activeSection === 'servicios' && (
          <ServiciosView
            onBookService={(tipo) => handleOpenBookModal(undefined, tipo)}
          />
        )}

        {activeSection === 'mascotas' && (
          <MascotasView
            currentUser={currentUser}
            mascotas={store.mascotas}
            propietarios={store.propietarios}
            turnos={store.turnos}
            onSelectPet={(id) => setSelectedPetId(id)}
            onBookForPet={(id) => handleOpenBookModal(id)}
            onOpenNewPetModal={() => {
              setNewPetOwnerId(
                currentUser?.rol === 'Clienta'
                  ? currentUser.propietarioId
                  : undefined
              );
              setNewPetModalOpen(true);
            }}
            onOpenAccess={openAccessPanel}
          />
        )}

        {activeSection === 'turnos' && (
          <TurnosView
            currentUser={currentUser}
            turnos={store.turnos}
            mascotas={store.mascotas}
            propietarios={store.propietarios}
            onChangeStatus={handleChangeTurnoStatus}
            onSelectTurno={(id) => setSelectedTurnoId(id)}
            onOpenBookModal={() => handleOpenBookModal()}
            onOpenAccess={openAccessPanel}
          />
        )}

        {activeSection === 'usuarios' && (
          <UsuariosView
            currentUser={currentUser}
            preferredAccessPanel={preferredAccessPanel}
            pendingBookingNotice={Boolean(pendingBooking)}
            propietarios={store.propietarios}
            mascotas={store.mascotas}
            turnos={store.turnos}
            onLoginClient={handleLoginClient}
            onRegisterClient={handleRegisterClient}
            onLoginAdmin={handleLoginAdmin}
            onLogout={handleLogout}
            onSelectPet={(id) => setSelectedPetId(id)}
            onBookForPet={(id) => handleOpenBookModal(id)}
            onChangeTurnoStatus={handleChangeTurnoStatus}
            onOpenNewOwnerModal={() => setNewOwnerModalOpen(true)}
            onOpenNewPetForOwner={(ownerId) => {
              setNewPetOwnerId(ownerId);
              setNewPetModalOpen(true);
            }}
            onGoToTurnos={() => navigateTo('turnos')}
          />
        )}

        {activeSection === 'contacto' && <ContactoView />}
      </main>

      {/* Pie de página sobrio */}
      <footer className="bg-white border-t border-slate-200 mt-auto">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-8 py-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <span className="font-semibold text-slate-800">Clínica Thiago</span>
            <span>Av. Santa Fe 3420, Palermo</span>
            <span className="font-mono tabular-nums">+54 11 4800-2210</span>
            {currentUser && (
              <span className="text-teal-700 font-medium">
                Sesión: {currentUser.rol}
              </span>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-4">
            {!confirmReset ? (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="inline-flex items-center gap-1.5 text-slate-500 hover:text-slate-800 transition-colors"
              >
                <RotateCcw size={13} />
                <span>Restaurar datos de ejemplo</span>
              </button>
            ) : (
              <div className="inline-flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleResetDemo}
                  className="px-2.5 py-1 text-xs font-medium text-white bg-slate-800 rounded-md hover:bg-slate-900"
                >
                  Confirmar restauración
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="px-2 py-1 text-xs text-slate-600 hover:text-slate-900"
                >
                  Cancelar
                </button>
              </div>
            )}
          </div>
        </div>
      </footer>

      {/* Modales y Drawers */}
      <BookAppointmentModal
        isOpen={bookModalOpen}
        onClose={() => setBookModalOpen(false)}
        currentUser={currentUser}
        mascotas={store.mascotas}
        propietarios={store.propietarios}
        turnos={store.turnos}
        preselectedMascotaId={bookPreselectedPetId}
        preselectedTipo={bookPreselectedTipo}
        onCreateAppointment={handleCreateAppointment}
      />

      <NewPetModal
        isOpen={newPetModalOpen}
        onClose={() => setNewPetModalOpen(false)}
        propietarios={store.propietarios}
        preselectedOwnerId={newPetOwnerId}
        lockOwner={currentUser?.rol === 'Clienta'}
        onCreatePet={handleCreatePet}
      />

      <NewOwnerModal
        isOpen={newOwnerModalOpen}
        onClose={() => setNewOwnerModalOpen(false)}
        onCreateOwner={handleCreateOwner}
      />

      <AppointmentDetailDrawer
        turno={selectedTurno}
        mascota={selectedTurno ? petMap.get(selectedTurno.mascotaId) : undefined}
        propietario={
          selectedTurno ? ownerMap.get(selectedTurno.propietarioId) : undefined
        }
        isAdmin={isAdmin}
        onClose={() => setSelectedTurnoId(null)}
        onChangeStatus={handleChangeTurnoStatus}
        onUpdateNotes={handleUpdateTurnoNotes}
        onOpenPetProfile={(mascotaId) => {
          setSelectedTurnoId(null);
          setSelectedPetId(mascotaId);
        }}
      />

      <PetDetailDrawer
        mascota={selectedPet}
        propietario={
          selectedPet ? ownerMap.get(selectedPet.propietarioId) : undefined
        }
        turnos={store.turnos}
        isAdmin={isAdmin}
        onClose={() => setSelectedPetId(null)}
        onBookForPet={(mascotaId) => {
          setSelectedPetId(null);
          handleOpenBookModal(mascotaId);
        }}
        onChangeStatus={handleChangeTurnoStatus}
        onSelectTurno={(turnoId) => {
          setSelectedPetId(null);
          setSelectedTurnoId(turnoId);
        }}
      />
    </div>
  );
}
